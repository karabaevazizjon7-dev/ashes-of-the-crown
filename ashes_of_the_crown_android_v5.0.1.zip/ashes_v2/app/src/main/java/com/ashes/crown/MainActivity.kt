package com.ashes.crown

import android.os.Bundle
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

private val Night = Color(0xFF17110E)
private val Leather = Color(0xFF302118)
private val Gold = Color(0xFFC6A05C)
private val Paper = Color(0xFFE9D9B8)
private val Ink = Color(0xFF352519)
private val Muted = Color(0xFF80633D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContent { MaterialTheme { AshesGame(this) } }
    }
}

private data class GameChoice(
    val title: String, val detail: String, val outcome: String,
    val reputation: Int = 0, val guard: Int = 0, val seleste: Int = 0,
    val gold: Int = 0, val health: Int = 0, val influence: Int = 0,
    val crown: Int = 0, val merchants: Int = 0, val commoners: Int = 0, val rose: Int = 0,
    val nextScene: Int
)
private data class Scene(val chapter: String, val title: String, val place: String, val text: String, val choices: List<GameChoice>)

private val scenes = listOf(
    Scene("ПРОЛОГ · СМЕРТЬ КОРОЛЯ", "Корона без короля", "Замок Эстерваль · рассвет", "Эстерваль. Год 1327. Король Альдрик III мёртв. Его нашли в запертой спальне, а на груди лежала чёрная роза — знак, исчезнувший из летописей триста лет назад.\n\nТы — Эдриан Вейл, младший хранитель королевских архивов. Прошлой ночью король передал тебе ключ и прошептал: «Когда погаснет последняя свеча, не верь тому, кто наденет корону».\n\nТеперь двери дворца заперты. Совет собирается через час. Капитан Гаррет Морн ждёт у архивной лестницы.", listOf(
        GameChoice("Передать капитану найденный свиток", "Доверие королевской гвардии", "Гаррет принимает свиток, но его лицо мрачнеет. На восковой печати — знак, которого нет ни в одном официальном реестре.", reputation=1, guard=12, crown=4, nextScene=1),
        GameChoice("Спрятать свиток в тайнике архива", "Скрыть улику и сохранить свободу действий", "Ты прячешь свиток за переплётом старой летописи. Между страниц обнаруживается записка: «Ищи наследника там, где река входит в камень». ", reputation=2, gold=2, rose=3, nextScene=2),
        GameChoice("Найти леди Селесту в зимнем саду", "Попытаться заключить опасный союз", "Леди Селеста слушает тебя молча. На её пальце блестит кольцо с чёрной розой. Она знает больше, чем говорит.", seleste=14, influence=2, rose=5, nextScene=3),
        GameChoice("Пойти на заседание королевского совета", "Услышать позиции великих домов", "Герцог Рейнар требует немедленной коронации. Селеста возражает: наследник исчез три дня назад. Совет раскалывается на два лагеря.", reputation=2, influence=4, crown=2, commoners=-1, nextScene=4)
    )),
    Scene("ГЛАВА I · ВЕРНОСТЬ", "Печать капитана", "Оружейная башня", "Гаррет запирает дверь и кладёт свиток на стол. «Я служил королю двадцать лет. Если эта печать настоящая, значит, приказы отдавали от имени мёртвого человека ещё до его смерти».\n\nКапитан предлагает сделку: ты помогаешь ему найти источник подделки, а он обеспечивает тебе безопасный проход по замку. Но доверие стражи — не то же самое, что дружба.", listOf(
        GameChoice("Согласиться работать вместе", "Союз с гвардией", "Гаррет протягивает руку. Отныне часть стражников будет сообщать тебе о подозрительных передвижениях.", reputation=1, guard=10, nextScene=5),
        GameChoice("Потребовать письменную гарантию", "Осторожная сделка", "Капитан усмехается, но ставит подпись под короткой грамотой. Он уважает твою осторожность, хотя доверяет не полностью.", influence=2, guard=4, nextScene=5),
        GameChoice("Отказаться и сохранить независимость", "Не связывать себя обещаниями", "Гаррет убирает свиток. «Тогда не стой у меня на пути». Ты уходишь, чувствуя на спине его тяжёлый взгляд.", reputation=-1, nextScene=5)
    )),
    Scene("ГЛАВА I · ТАЙНА", "Чернила под переплётом", "Запретный архив", "Ты возвращаешься к тайнику. На внутренней стороне обложки выдавлены семь имён — названия великих домов. Одно имя зачёркнуто так сильно, что пергамент почти прорван.\n\nВнизу страницы есть схема старого водостока, ведущего к реке. Кто-то оставил тебе путь из замка — или ловушку.", listOf(
        GameChoice("Изучить шифр и карту", "Потратить время на разгадку", "За несколькими слоями чернил обнаруживается герб исчезнувшего дома. Ты запоминаешь расположение тайного хода.", influence=3, nextScene=5),
        GameChoice("Покинуть замок через водосток", "Рискнуть ради свободы", "Камни скользкие, вода ледяная. Ты выбираешься к реке, но теряешь часть припасов.", health=-8, gold=-2, nextScene=5),
        GameChoice("Подбросить ложную улику в покои Рейнара", "Опасная политическая игра", "Слухи о герцоге начинают распространяться. Ты выиграл время, но если обман раскроют, враг будет беспощаден.", reputation=-2, influence=5, nextScene=5)
    )),
    Scene("ГЛАВА I · СОЮЗ", "Леди в серебряной вуали", "Зимний сад", "Селеста касается кольца с чёрной розой. «Во дворце правду не находят, Эдриан. Её выбирают — и платят за неё».\n\nОна предлагает доступ к переписке великих домов, но просит взамен одну услугу: выяснить, кто подменил страницу в книге наследования.", listOf(
        GameChoice("Показать ей копию печати", "Открытость и доверие", "Селеста впервые улыбается. Она узнаёт символ и обещает познакомить тебя с человеком, который видел его раньше.", seleste=12, reputation=1, nextScene=5),
        GameChoice("Спросить прямо о её кольце", "Давление вместо дипломатии", "Её улыбка исчезает. «Любопытство — опасная привычка». Она не прогоняет тебя, но разговор окончен.", seleste=-5, influence=1, nextScene=5),
        GameChoice("Предложить обмен архивной тайной", "Переговоры на равных", "Селеста принимает условия. Теперь у вас есть общий секрет — и причина опасаться друг друга.", seleste=8, gold=3, nextScene=5)
    )),
    Scene("ГЛАВА I · СОВЕТ", "Семь голосов", "Зал великого совета", "Под сводами зала спорят представители великих домов. Герцог Рейнар говорит о порядке, Селеста — о законном наследовании. Старые союзники уже не смотрят друг другу в глаза.\n\nТы замечаешь, что один из лордов носит перстень с тем же знаком, что был на свитке.", listOf(
        GameChoice("Публично потребовать расследования", "Выступить перед знатью", "Голоса стихают. Ты привлёк внимание всего совета — и нажил влиятельных противников.", reputation=4, influence=3, commoners=5, crown=-2, nextScene=5),
        GameChoice("Незаметно проследить за лордом", "Собрать доказательства", "Ты покидаешь зал следом за незнакомцем. Он направляется к старому мосту за городскими стенами.", influence=2, nextScene=5),
        GameChoice("Поддержать предложение о временном регентстве", "Выбрать сторону порядка", "Рейнар благодарит тебя. Но Селеста смотрит так, словно запомнила этот момент навсегда.", reputation=1, guard=2, seleste=-4, nextScene=5)
    )),
    Scene("ГЛАВА II · ГОРОД", "Город просыпается", "Нижние ворота Эстервала", "За стенами замка шумит рынок. В городе уже знают о смерти короля, но каждый рассказывает свою версию. Торговцы боятся закрытия дорог, ремесленники — новых налогов, а нищие шепчут о человеке, которого видели у старого моста.\n\nПеред тобой три пути. От твоего выбора зависит, какие двери откроются дальше.", listOf(
        GameChoice("Отправиться к старому мосту", "След наследника", "У реки ты находишь свежие следы конского копыта и обрывок синего плаща. Кто-то недавно ждал здесь важного гостя.", influence=2, nextScene=6),
        GameChoice("Расспросить торговцев на рынке", "Слухи и связи", "Торговка специями рассказывает о ночной поставке в замок. За сведения она просит небольшую плату.", gold=-3, reputation=2, merchants=5, commoners=2, nextScene=7),
        GameChoice("Посетить особняк одного из великих домов", "Политическое влияние", "Тебя принимают не сразу. Но управляющий соглашается передать письмо лорду, если ты докажешь свою полезность.", influence=5, nextScene=8)
    )),
    Scene("ГЛАВА II · РЕКА", "След у старого моста", "Старый мост", "Под мостом скрывается каменная дверь. На ней семь углублений для печатей, но одно из них покрыто свежей сажей. Из темноты доносится тихий стук — три раза, пауза, ещё два.\n\nТы понимаешь: это не просто тайник. Это место встречи людей, которые не хотят, чтобы их видели при свете дня.", listOf(
        GameChoice("Ответить условным стуком", "Попытаться войти мирно", "За дверью слышится движение. Незнакомый голос спрашивает пароль, которого ты не знаешь.", health=-2, influence=2, nextScene=9),
        GameChoice("Осмотреть каменную кладку", "Найти скрытый механизм", "В шве кладки ты находишь маленький медный ключ с гербом без короны.", gold=1, nextScene=9),
        GameChoice("Вернуться в город и подготовиться", "Не рисковать без сведений", "Ты отходишь от моста. Теперь ты знаешь место, но неизвестные могли заметить тебя.", reputation=1, nextScene=9)
    )),
    Scene("ГЛАВА II · РЫНОК", "Цена слухов", "Рыночная площадь", "Торговка показывает тебе список поставок. Среди обычных товаров значатся семь ящиков чёрного воска — материала, которым запечатывали королевские приказы.\n\nОна предлагает продать тебе копию накладной. Это может стать доказательством, если найти того, кто оплатил груз.", listOf(
        GameChoice("Купить копию накладной", "Заплатить за улику", "Ты получаешь документ с печатью портового склада. След ведёт к Веймару.", gold=-4, influence=3, merchants=3, rose=2, nextScene=9),
        GameChoice("Уговорить торговку помочь бесплатно", "Использовать убеждение", "Она соглашается, если ты пообещаешь защитить её лавку от новых поборов.", reputation=2, nextScene=9),
        GameChoice("Отказаться от сделки", "Сохранить золото", "Ты уходишь без документа. Но запоминаешь имя складского писаря.", nextScene=9)
    )),
    Scene("ГЛАВА II · ДОМ", "За закрытыми ставнями", "Особняк великого дома", "Управляющий проводит тебя в комнату без окон. На столе лежит карта королевства и семь фигурок из чёрного дерева. Одна фигурка уже перевёрнута.\n\n«Нам нужен человек, который умеет читать старые договоры», — говорит управляющий. «Но прежде чем говорить о союзе, докажи, что умеешь хранить тайны».", listOf(
        GameChoice("Согласиться прочесть древний договор", "Показать знания архивариуса", "Ты находишь в договоре скрытый пункт о праве убежища. Управляющий впечатлён.", influence=4, reputation=1, nextScene=9),
        GameChoice("Спросить, кто перевернул фигурку", "Проявить политическую смелость", "Управляющий закрывает карту. «Ты задаёшь правильные вопросы не в то время».", influence=1, nextScene=9),
        GameChoice("Отказаться от сомнительного союза", "Сохранить независимость", "Тебя провожают без угроз, но двери этого дома теперь будут открываться не так легко.", reputation=1, nextScene=9)
    )),
    Scene("ГЛАВА III · НОВАЯ УЛИКА", "Семь печатей", "Тайное убежище", "К концу дня у тебя появляется несколько нитей, ведущих к одной тайне. Чёрная роза — не знак убийцы. Это знак старого договора, заключённого семью домами до основания Эстервала.\n\nКто-то пытается стереть имя настоящего наследника. Но пока ты не знаешь, кому выгодно вернуть его — и кому выгодно, чтобы он никогда не появился.", listOf(
        GameChoice("Продолжить расследование вместе с Гарретом", "Опора на гвардию", "Гаррет обещает людей и доступ к караульным журналам.", guard=8, nextScene=10),
        GameChoice("Попросить помощи у Селесты", "Опора на двор", "Селеста обещает устроить встречу с посланником одного из домов.", seleste=8, nextScene=10),
        GameChoice("Начать собственную сеть осведомителей", "Независимая игра", "Ты нанимаешь двух городских мальчишек собирать слухи. Это дорого, но теперь у тебя есть глаза на улицах.", gold=-5, influence=6, nextScene=10)
    )),
    Scene("ГЛАВА III · ПЕРЕДЫШКА", "Перед бурей", "Комната над трактиром", "Ночь опускается на Эстерваль. Ты раскладываешь найденные бумаги и понимаешь, что расследование только начинается. Королевство ещё не знает, кто станет править им завтра.\n\nЭто конец первой игровой части прототипа. Следующая глава добавит путешествия по владениям домов, торговлю, новые знакомства и более сложные политические решения.", listOf(
        GameChoice("Вернуться к началу главы и пересмотреть путь", "Переиграть решения", "Твои сохранённые параметры останутся прежними, но история вернётся к первому выбору.", nextScene=0),
        GameChoice("Остаться в городе и изучить связи", "Продолжить свободное исследование", "Ты решаешь задержаться в городе. Впереди новые возможности и новые опасности.", influence=1, nextScene=10)
    ))
)

@Composable
private fun AshesGame(activity: ComponentActivity) {
    val prefs = remember { activity.getSharedPreferences("ashes_save_v2", 0) }
    var musicEnabled by remember { mutableStateOf(prefs.getBoolean("music_enabled", true)) }
    val latestMusicEnabled by rememberUpdatedState(musicEnabled)
    val musicPlayer = remember {
        MediaPlayer.create(activity, R.raw.estervale_ambient)?.apply {
            isLooping = true
            setVolume(0.34f, 0.34f)
        }
    }
    LaunchedEffect(musicEnabled) {
        if (musicEnabled) {
            if (musicPlayer != null && !musicPlayer.isPlaying) musicPlayer.start()
        } else if (musicPlayer?.isPlaying == true) {
            musicPlayer.pause()
        }
    }
    DisposableEffect(activity, musicPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> if (latestMusicEnabled && musicPlayer != null && !musicPlayer.isPlaying) musicPlayer.start()
                Lifecycle.Event.ON_STOP -> if (musicPlayer?.isPlaying == true) musicPlayer.pause()
                else -> Unit
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose {
            activity.lifecycle.removeObserver(observer)
            musicPlayer?.release()
        }
    }
    var sceneIndex by remember { mutableIntStateOf(prefs.getInt("scene", 0).coerceIn(scenes.indices)) }
    var reputation by remember { mutableIntStateOf(prefs.getInt("rep", 0)) }
    var guard by remember { mutableIntStateOf(prefs.getInt("guard", 20)) }
    var seleste by remember { mutableIntStateOf(prefs.getInt("seleste", 0)) }
    var gold by remember { mutableIntStateOf(prefs.getInt("gold", 18)) }
    var health by remember { mutableIntStateOf(prefs.getInt("hp", 100)) }
    var influence by remember { mutableIntStateOf(prefs.getInt("inf", 0)) }
    var crownRep by remember { mutableIntStateOf(prefs.getInt("f_crown", 0)) }
    var merchantRep by remember { mutableIntStateOf(prefs.getInt("f_merchants", 0)) }
    var peopleRep by remember { mutableIntStateOf(prefs.getInt("f_people", 0)) }
    var roseRep by remember { mutableIntStateOf(prefs.getInt("f_rose", 0)) }
    var questStage by remember { mutableIntStateOf(prefs.getInt("quest_market", 0)) }
    var roseQuestStage by remember { mutableIntStateOf(prefs.getInt("quest_rose_chain", 0).coerceIn(0, 5)) }
    var roseQuestPath by remember { mutableIntStateOf(prefs.getInt("quest_rose_path", 0)) }
    var housesQuestStage by remember { mutableIntStateOf(prefs.getInt("quest_houses_stage", 0).coerceIn(0, 3)) }
    var housesQuestPath by remember { mutableIntStateOf(prefs.getInt("quest_houses_path", 0).coerceIn(0, 3)) }
    var garrettMemory by remember { mutableIntStateOf(prefs.getInt("mem_garrett", 0)) }
    var selesteMemory by remember { mutableIntStateOf(prefs.getInt("mem_seleste", 0)) }
    var randomEventCount by remember { mutableIntStateOf(prefs.getInt("events", 0)) }
    var thomasMemory by remember { mutableIntStateOf(prefs.getInt("mem_thomas", 0)) }
    var miraMemory by remember { mutableIntStateOf(prefs.getInt("mem_mira", 0)) }
    var thomasBond by remember { mutableIntStateOf(prefs.getInt("bond_thomas", 8).coerceIn(-100,100)) }
    var miraBond by remember { mutableIntStateOf(prefs.getInt("bond_mira", 12).coerceIn(-100,100)) }
    var reynarBond by remember { mutableIntStateOf(prefs.getInt("bond_reynar", -5).coerceIn(-100,100)) }
    var socialConflict by remember { mutableIntStateOf(prefs.getInt("social_conflict", 0).coerceIn(0,3)) }
    var socialEvent by remember { mutableStateOf(prefs.getString("social_event", "В Эстервaле пока царит хрупкое перемирие между знакомыми тебе людьми.") ?: "В Эстервaле пока царит хрупкое перемирие между знакомыми тебе людьми.") }
    var personalQuestFlags by remember { mutableIntStateOf(prefs.getInt("personal_quests", 0)) }
    var dungeonKeep by remember { mutableIntStateOf(prefs.getInt("dungeon_keep", 0).coerceIn(0,4)) }
    var dungeonCrypt by remember { mutableIntStateOf(prefs.getInt("dungeon_crypt", 0).coerceIn(0,4)) }
    var dungeonArchive by remember { mutableIntStateOf(prefs.getInt("dungeon_archive", 0).coerceIn(0,4)) }
    var expeditionNote by remember { mutableStateOf(prefs.getString("expedition_note", "Три забытых места ждут исследователя.") ?: "Три забытых места ждут исследователя.") }
    var weatherSeed by remember { mutableIntStateOf(prefs.getInt("weather_seed", 0)) }
    var craftedCount by remember { mutableIntStateOf(prefs.getInt("crafted_count", 0)) }
    var councilProgress by remember { mutableIntStateOf(prefs.getInt("council_progress", 0).coerceIn(0, 3)) }
    var councilBalance by remember { mutableIntStateOf(prefs.getInt("council_balance", 0).coerceIn(-20, 20)) }
    var councilReport by remember { mutableStateOf(prefs.getString("council_report", "Совет семи домов ждёт твоего первого выступления.") ?: "Совет семи домов ждёт твоего первого выступления.") }
    var companion by remember { mutableStateOf(prefs.getString("companion", "Гаррет Морн") ?: "Гаррет Морн") }
    var expeditionRuns by remember { mutableIntStateOf(prefs.getInt("expedition_runs", 0)) }
    var companionBond by remember { mutableIntStateOf(prefs.getInt("companion_bond", 0).coerceIn(-100, 100)) }
    var expeditionReport by remember { mutableStateOf(prefs.getString("expedition_report", "Выбери спутника и отправляйся в путь.") ?: "Выбери спутника и отправляйся в путь.") }
    var frontierStage by remember { mutableIntStateOf(prefs.getInt("frontier_stage", 0).coerceIn(0, 3)) }
    var frontierRoute by remember { mutableIntStateOf(prefs.getInt("frontier_route", 0).coerceIn(0, 3)) }
    var frontierThreat by remember { mutableIntStateOf(prefs.getInt("frontier_threat", 50).coerceIn(0, 100)) }
    var frontierReport by remember { mutableStateOf(prefs.getString("frontier_report", "Северные земли ждут решения Совета.") ?: "Северные земли ждут решения Совета.") }
    var selectedPage by remember { mutableStateOf("story") }
    var menuVisible by remember { mutableStateOf(true) }
    var dialogNpc by remember { mutableStateOf(prefs.getString("dialog_npc", "Гаррет Морн") ?: "Гаррет Морн") }
    var dialogStage by remember { mutableIntStateOf(prefs.getInt("dialog_stage", 0).coerceIn(0, 3)) }
    var dialogTrust by remember { mutableIntStateOf(prefs.getInt("dialog_trust", 0).coerceIn(-20, 20)) }
    var enemyName by remember { mutableStateOf(prefs.getString("battle_enemy", "") ?: "") }
    var enemyHealth by remember { mutableIntStateOf(prefs.getInt("battle_enemy_hp", 0)) }
    var battleWins by remember { mutableIntStateOf(prefs.getInt("battle_wins", 0)) }
    var experience by remember { mutableIntStateOf(prefs.getInt("experience", 0)) }
    var heroLevel by remember { mutableIntStateOf(prefs.getInt("hero_level", 1).coerceAtLeast(1)) }
    var skillPoints by remember { mutableIntStateOf(prefs.getInt("skill_points", 0)) }
    var powerSkill by remember { mutableIntStateOf(prefs.getInt("skill_power", 0)) }
    var guardSkill by remember { mutableIntStateOf(prefs.getInt("skill_guard", 0)) }
    var battlePulse by remember { mutableIntStateOf(0) }
    var encounterCount by remember { mutableIntStateOf(prefs.getInt("encounters", 0)) }
    val enemyHitScale by animateFloatAsState(targetValue = if (battlePulse % 2 == 0) 1f else 0.94f, label = "enemyHit")
    var battleLog by remember { mutableStateOf(prefs.getString("battle_log", "Здесь появится ход сражения.") ?: "Здесь появится ход сражения.") }
    var battleGuarding by remember { mutableStateOf(false) }
    var currentLocation by remember { mutableStateOf(prefs.getString("location", "Королевский замок") ?: "Королевский замок") }
    var worldDay by remember { mutableIntStateOf(prefs.getInt("world_day", 1).coerceAtLeast(1)) }
    var worldHour by remember { mutableIntStateOf(prefs.getInt("world_hour", 9).coerceIn(0, 23)) }
    var worldEvent by remember { mutableStateOf(prefs.getString("world_event", "Город просыпается под звон колоколов.") ?: "Город просыпается под звон колоколов.") }
    var lastOutcome by remember { mutableStateOf(prefs.getString("outcome", null)) }
    var chosen by remember { mutableStateOf(prefs.getBoolean("chosen", false)) }
    val journal = remember { mutableStateListOf<String>().apply { addAll(prefs.getString("journal", "").orEmpty().split("¦").filter { it.isNotBlank() }) } }
    val inventory = remember { mutableStateListOf<String>().apply { addAll(prefs.getString("items", "Архивный ключ¦Дорожный плащ¦Пустой блокнот").orEmpty().split("¦").filter { it.isNotBlank() }) } }
    fun save() {
        prefs.edit().putInt("scene", sceneIndex).putInt("rep", reputation).putInt("guard", guard)
            .putInt("seleste", seleste).putInt("gold", gold).putInt("hp", health).putInt("inf", influence)
            .putInt("f_crown", crownRep).putInt("f_merchants", merchantRep).putInt("f_people", peopleRep).putInt("f_rose", roseRep)
            .putInt("quest_market", questStage).putInt("quest_rose_chain", roseQuestStage).putInt("quest_rose_path", roseQuestPath).putInt("quest_houses_stage", housesQuestStage).putInt("quest_houses_path", housesQuestPath).putInt("mem_garrett", garrettMemory).putInt("mem_seleste", selesteMemory).putInt("events", randomEventCount)
            .putInt("mem_thomas", thomasMemory).putInt("mem_mira", miraMemory).putInt("bond_thomas", thomasBond).putInt("bond_mira", miraBond).putInt("bond_reynar", reynarBond).putInt("social_conflict", socialConflict).putString("social_event", socialEvent).putInt("personal_quests", personalQuestFlags)
            .putString("location", currentLocation).putInt("world_day", worldDay).putInt("world_hour", worldHour).putString("world_event", worldEvent)
            .putString("battle_enemy", enemyName).putInt("battle_enemy_hp", enemyHealth)
            .putInt("battle_wins", battleWins).putString("battle_log", battleLog)
            .putInt("experience", experience).putInt("hero_level", heroLevel).putInt("skill_points", skillPoints)
            .putInt("skill_power", powerSkill).putInt("skill_guard", guardSkill).putInt("encounters", encounterCount)
            .putString("outcome", lastOutcome).putBoolean("chosen", chosen)
            .putString("dialog_npc", dialogNpc).putInt("dialog_stage", dialogStage).putInt("dialog_trust", dialogTrust)
            .putString("journal", journal.joinToString("¦")).putString("items", inventory.joinToString("¦"))
            .putInt("dungeon_keep", dungeonKeep).putInt("dungeon_crypt", dungeonCrypt).putInt("dungeon_archive", dungeonArchive)
            .putString("expedition_note", expeditionNote).putInt("weather_seed", weatherSeed).putInt("crafted_count", craftedCount)
            .putInt("council_progress", councilProgress).putInt("council_balance", councilBalance).putString("council_report", councilReport)
            .putString("companion", companion).putInt("expedition_runs", expeditionRuns).putInt("companion_bond", companionBond).putString("expedition_report", expeditionReport)
            .putInt("frontier_stage", frontierStage).putInt("frontier_route", frontierRoute).putInt("frontier_threat", frontierThreat).putString("frontier_report", frontierReport).apply()
    }
    fun saveSlot(slot: Int) {
        save()
        val snapshot = JSONObject()
        prefs.all.forEach { (key, value) ->
            if (!key.startsWith("slot_") && value != null) snapshot.put(key, value)
        }
        prefs.edit().putString("slot_${slot}_data", snapshot.toString())
            .putString("slot_${slot}_label", "День $worldDay · ${worldHour.toString().padStart(2, '0')}:00 · $currentLocation").apply()
    }
    fun loadSlot(slot: Int) {
        val raw = prefs.getString("slot_${slot}_data", null) ?: return
        val snapshot = JSONObject(raw)
        val editor = prefs.edit()
        val keepMusic = prefs.getBoolean("music_enabled", true)
        editor.clear().putBoolean("music_enabled", keepMusic)
        for (key in snapshot.keys()) {
            when (val value = snapshot.get(key)) {
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Double -> editor.putFloat(key, value.toFloat())
                JSONObject.NULL -> editor.remove(key)
                else -> editor.putString(key, value.toString())
            }
        }
        for (i in 1..3) {
            prefs.getString("slot_${i}_data", null)?.let { editor.putString("slot_${i}_data", it) }
            prefs.getString("slot_${i}_label", null)?.let { editor.putString("slot_${i}_label", it) }
        }
        editor.apply()
        activity.recreate()
    }
    fun makeChoice(choice: GameChoice) {
        reputation += choice.reputation; guard = (guard + choice.guard).coerceIn(0, 100)
        seleste = (seleste + choice.seleste).coerceIn(-100, 100); gold = (gold + choice.gold).coerceAtLeast(0)
        health = (health + choice.health).coerceIn(0, 100); influence += choice.influence
        crownRep = (crownRep + choice.crown).coerceIn(-100, 100); merchantRep = (merchantRep + choice.merchants).coerceIn(-100, 100)
        peopleRep = (peopleRep + choice.commoners).coerceIn(-100, 100); roseRep = (roseRep + choice.rose).coerceIn(-100, 100)
        lastOutcome = choice.outcome; journal.add("${scenes[sceneIndex].title}: ${choice.title}")
        if (choice.outcome.contains("медный ключ")) inventory.add("Медный ключ без короны")
        if (choice.outcome.contains("накладной")) inventory.add("Копия портовой накладной")
        sceneIndex = choice.nextScene.coerceIn(scenes.indices); chosen = true; selectedPage = "story"; save()
    }
    fun beginBattle(name: String, hp: Int) {
        enemyName = name; enemyHealth = hp; battleLog = "$name выходит из тумана. Он замечает тебя и поднимает оружие."
        battleGuarding = false; selectedPage = "battle"; save()
    }
    fun enemyTurn() {
        if (enemyHealth <= 0) return
        val rawDamage = (7..13).random() + if (enemyName.contains("Древний рыцарь")) 4 else 0
        val armor = (if (inventory.contains("Кольчуга стражника")) 3 else 0) + guardSkill * 2
        val damage = if (battleGuarding) (rawDamage / 2 - armor).coerceAtLeast(1) else (rawDamage - armor).coerceAtLeast(1)
        health = (health - damage).coerceAtLeast(0)
        battleLog += "\n$enemyName наносит $damage урона${if (battleGuarding) "; стойка помогла смягчить удар" else ""}."
        battleGuarding = false
        if (health == 0) {
            health = 25
            gold = (gold - 3).coerceAtLeast(0)
            battleLog += "\nТы теряешь сознание. Стражники находят тебя и возвращают в безопасное место. Потеряно 3 золота; здоровье восстановлено до 25."
            enemyHealth = 0; enemyName = ""
        }
        save()
    }
    fun winBattle() {
        val defeated = enemyName
        val rewardXp = when { defeated.contains("Древний рыцарь") -> 90; defeated.contains("Наёмник") -> 35; defeated.contains("изменник") -> 50; else -> 20 }
        battleWins++; gold += if (defeated.contains("Древний рыцарь")) 25 else 5; reputation++
        experience += rewardXp
        while (experience >= heroLevel * 100) { experience -= heroLevel * 100; heroLevel++; skillPoints++ }
        journal.add("Победа в бою: $defeated. Получено опыта: $rewardXp.")
        battleLog += "\nПобеда! Получено $rewardXp опыта${if (defeated.contains("Древний рыцарь")) " и 25 золотых" else " и 5 золотых"}."
        inventory.add("Трофей: знак побеждённого противника")
        enemyHealth = 0; enemyName = ""; save()
    }
    fun startRandomEncounter() {
        encounterCount++
        val roll = (1..100).random()
        val (name, hp) = when {
            roll <= 8 -> "Древний рыцарь Чёрной розы" to 105
            roll <= 35 -> "Наёмник Чёрной розы" to 48
            roll <= 68 -> "Городской головорез" to 32
            else -> "Дорожный разбойник" to 25
        }
        journal.add("Случайная встреча в пути: $name.")
        beginBattle(name, hp)
        battleLog = "В пути внезапно появляется $name. Бежать или принять бой?"
        save()
    }
    fun advanceWorldTime(hours: Int) {
        val before = worldHour
        val total = worldHour + hours
        worldDay += total / 24
        worldHour = total % 24
        val phase = when (worldHour) { in 5..10 -> "утро"; in 11..16 -> "день"; in 17..20 -> "вечер"; else -> "ночь" }
        worldEvent = when {
            before < 18 && worldHour >= 18 -> "На улицах зажигают фонари. Стража усиливает патрули, а торговцы закрывают лавки."
            before < 6 && worldHour >= 6 -> "Колокола возвещают рассвет. Рынок постепенно наполняется людьми."
            worldHour in 22..23 || worldHour in 0..4 -> "Ночные улицы почти пусты. В переулках слышны шаги, а у ворот проверяют путников."
            else -> "В Эстервaле сейчас $phase. Горожане заняты повседневными делами."
        }
        journal.add("Время: день $worldDay, ${worldHour.toString().padStart(2, '0')}:00. $worldEvent")
        save()
    }
    val timePhase = when (worldHour) { in 5..10 -> "Утро"; in 11..16 -> "День"; in 17..20 -> "Вечер"; else -> "Ночь" }
    val scene = scenes[sceneIndex]
    val availableChoices = buildList {
        addAll(scene.choices)
        if (sceneIndex == 5 && guard >= 30) add(GameChoice("Потребовать сопровождение гвардии", "Открывается благодаря доверию капитана", "Гаррет выделяет двух надёжных стражников. Их присутствие заставляет городских осведомителей говорить осторожнее, но безопаснее.", guard=4, reputation=1, nextScene=6))
        if (sceneIndex == 5 && seleste >= 15) add(GameChoice("Передать тайное послание Селесты", "Открывается благодаря доверию леди", "Посланник Селесты приносит знак допуска к закрытому причалу. На обороте записано имя человека, видевшего наследника.", seleste=3, rose=2, nextScene=8))
        if (sceneIndex == 9 && influence >= 8) add(GameChoice("Созвать собственных осведомителей", "Открывается при высоком влиянии", "Твои связи позволяют собрать людей из разных кварталов. В обмен на обещание защиты они соглашаются следить за ночными перевозками.", gold=-2, influence=2, commoners=2, nextScene=10))
        if (sceneIndex == 9 && inventory.contains("Медный ключ без короны")) add(GameChoice("Использовать медный ключ у каменной двери", "Открывается, если ключ найден ранее", "Ключ поворачивается с сухим щелчком. За дверью обнаруживается лестница в старое убежище, а на стене — карта семи домов.", rose=4, influence=3, nextScene=10))
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF493423), Night, Color(0xFF0C0908)))).padding(10.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("✦ ХРОНИКИ ЭСТЕРВАЛЯ ✦", color = Gold, fontSize = 10.sp, letterSpacing = 3.sp); Text("ПЕПЕЛ КОРОНЫ", color = Paper, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif) }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    TextButton(onClick = { menuVisible = true }) { Text("☰ МЕНЮ", color = Gold, fontSize = 9.sp) }
                    Button(onClick = {
                        musicEnabled = !musicEnabled
                        prefs.edit().putBoolean("music_enabled", musicEnabled).apply()
                    }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp), shape = RoundedCornerShape(4.dp), colors = ButtonDefaults.buttonColors(containerColor = if (musicEnabled) Gold else Leather, contentColor = if (musicEnabled) Ink else Paper)) {
                        Text(if (musicEnabled) "♫ МУЗЫКА ВКЛ." else "♫ МУЗЫКА ВЫКЛ.", fontSize = 9.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) { Text("1327 ГОД · ДЕНЬ ${sceneIndex + 1}", color = Gold, fontSize = 11.sp); Text("АВТОСОХРАНЕНИЕ", color = Color(0xFFB9A47E), fontSize = 9.sp) }
                }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("📖 История" to "story", "💬 Диалоги" to "dialogues", "⚔ Бой" to "battle", "👤 Персонаж" to "hero", "🤝 Отношения" to "people", "🗺 Мир" to "world", "⚜ Дома" to "houses", "🏘 Жизнь" to "life", "📌 Задания" to "quests", "🗝 Экспедиции" to "expeditions", "🏛 Совет" to "council", "🧭 Спутники" to "companions", "🏔 Северный поход" to "frontier", "🎒 Инвентарь" to "items", "📜 Летопись" to "journal", "✦ Об игре" to "about").forEach { (label, key) ->
                    Button(onClick = { selectedPage = key }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp), shape = RoundedCornerShape(3.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selectedPage == key) Gold else Leather, contentColor = if (selectedPage == key) Ink else Paper)) { Text(label, fontSize = 10.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Column(Modifier.weight(1.08f).fillMaxHeight().background(Paper, RoundedCornerShape(4.dp)).border(3.dp, Color(0xFF89683E), RoundedCornerShape(4.dp)).padding(15.dp).verticalScroll(rememberScrollState())) {
                    when (selectedPage) {
                        "frontier" -> {
                            PaperHeading("ГЛАВА III · СЕВЕРНЫЙ ПОХОД")
                            Text("За перевалом лежит марка Вальден — последний рубеж перед древней дорогой к столице. После решений Совета северные дома требуют гарантий, а разведчики сообщают о людях Чёрной розы среди наёмников.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(8.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("МАРКА ВАЛЬДЕН · СЕВЕРНЫЕ ЗЕМЛИ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Этап похода: $frontierStage / 3", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("Угроза на тракте: $frontierThreat / 100", color = Ink, fontSize = 12.sp)
                                    LinearProgressIndicator(progress = { frontierThreat / 100f }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Color(0xFF876039), trackColor = Color(0xFFB99E72))
                                    Spacer(Modifier.height(7.dp))
                                    Text(frontierReport, color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            if (housesQuestStage < 3) {
                                Text("Сначала заверши главу Совета семи домов: северные лорды не станут вести переговоры с неизвестным посланником.", color = Color(0xFF8B382B), fontSize = 12.sp)
                                Button(onClick = { selectedPage = "quests" }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Перейти к заданиям", color = Paper) }
                            } else when (frontierStage) {
                                0 -> {
                                    Text("I · ПЕРЕВАЛ ВОРОНОВ. Разведчики нашли три пути к крепости: открытая дорога, старый шахтёрский тоннель и переговоры с кланом горцев.", color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                                    Button(onClick = { frontierRoute = 1; frontierThreat = (frontierThreat - 12).coerceAtLeast(0); guard += 3; gold = (gold - 4).coerceAtLeast(0); frontierStage = 1; frontierReport = "Гаррет провёл отряд по открытой дороге. Дозорные Вальдена увидели королевский знак и пропустили вас, но запасы пришлось пополнить."; advanceWorldTime(6); journal.add("Северный поход: выбран открытый путь через Перевал Воронов."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Открытая дорога · поддержка гвардии", color = Paper) }
                                    Button(onClick = { frontierRoute = 2; influence += 3; health = (health - 8).coerceAtLeast(1); frontierStage = 1; frontierReport = "Ты провёл людей через шахтёрский тоннель. В глубине обнаружен тайный склад снаряжения и следы недавнего присутствия наёмников."; inventory.add("Шахтёрская карта Вальдена"); advanceWorldTime(8); journal.add("Северный поход: тайный путь через шахту."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Старый тоннель · риск и тайна", color = Paper) }
                                    Button(onClick = { frontierRoute = 3; peopleRep += 4; companionBond += 2; frontierStage = 1; frontierReport = "Мира помогла найти старейшину горцев. Клан согласился провести отряд через перевал, если корона защитит их зимние поселения."; inventory.add("Знак клана горцев"); advanceWorldTime(5); journal.add("Северный поход: заключено соглашение с горцами."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Переговоры с горцами · союз", color = Paper) }
                                }
                                1 -> {
                                    Text("II · ДЕРЕВНЯ СЕРОГО БРОДА. На деревню напали люди в одинаковых серых плащах. Среди них замечен знак Чёрной розы. Реши, что важнее: жители, доказательства или быстрый удар.", color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                                    Button(onClick = { frontierThreat = (frontierThreat - 18).coerceAtLeast(0); peopleRep += 6; health = (health - 5).coerceAtLeast(1); frontierStage = 2; frontierReport = "Ты вывел жителей из горящих домов. Староста передал имена пропавших людей и ключ от старого дозорного поста."; inventory.add("Список пропавших жителей"); advanceWorldTime(4); journal.add("Северный поход: спасены жители Серого Брода."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Спасти жителей · доверие народа", color = Paper) }
                                    Button(onClick = { frontierThreat = (frontierThreat - 8).coerceAtLeast(0); influence += 5; roseRep += 3; frontierStage = 2; frontierReport = "Ты захватил связного и добыл шифр приказов. Деревня понесла потери, но теперь известен следующий пункт тайной сети."; inventory.add("Зашифрованный приказ Чёрной розы"); advanceWorldTime(3); journal.add("Северный поход: захвачен связной Чёрной розы."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Захватить связного · добыть улики", color = Paper) }
                                    Button(onClick = { frontierThreat = (frontierThreat - 25).coerceAtLeast(0); reputation += 2; gold = (gold - 5).coerceAtLeast(0); frontierStage = 2; frontierReport = "Гаррет повёл внезапную атаку. Нападавшие разбиты, но часть улик уничтожена в суматохе."; advanceWorldTime(2); journal.add("Северный поход: проведена внезапная атака."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Немедленный штурм · военная сила", color = Paper) }
                                }
                                2 -> {
                                    Text("III · КРЕПОСТЬ ВАЛЬДЕН. Внутренние ворота открыты, но командир крепости утверждает, что действует по королевскому приказу. На столе лежит документ с печатью, которую ты уже видел в архиве.", color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                                    Button(onClick = { frontierStage = 3; crownRep += 6; influence += 4; gold += 12; experience += 100; inventory.add("Приказ регента о северной смуте"); frontierReport = "Ты предъявил улики и добился признания командира. Приказ регента доказывает, что мятеж на севере был спровоцирован из столицы. Крепость признаёт твоё право говорить от имени короны."; journal.add("Глава III завершена: раскрыта провокация регента в Марке Вальден."); advanceWorldTime(3); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Предъявить доказательства · раскрыть заговор", color = Ink) }
                                    Button(onClick = { frontierStage = 3; guard += 8; reputation += 4; gold += 8; experience += 100; inventory.add("Знамя гарнизона Вальдена"); frontierReport = "Ты принял вызов командира и победил в поединке. Гарнизон подчинился силе, но часть дворян считает тебя опасным человеком."; journal.add("Глава III завершена: крепость Вальден подчинена после поединка."); advanceWorldTime(2); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Вызвать командира на поединок · честь и сила", color = Paper) }
                                }
                                else -> {
                                    Text("МАРКА ВАЛЬДЕН ПОД КОНТРОЛЕМ", color = Color(0xFF527044), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Твой путь: ${when(frontierRoute) { 1 -> "королевская дорога"; 2 -> "шахтёрский тоннель"; else -> "союз с горцами" }}. Северные владения теперь связаны с твоими решениями. В летописи сохранена развязка главы.", color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                                    Button(onClick = { selectedPage = "journal" }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Открыть летопись", color = Paper) }
                                }
                            }
                        }
                        "battle" -> {
                            PaperHeading("БОЕВОЙ ЖУРНАЛ · СТАЛЬ И ВОЛЯ")
                            Text("Пошаговые схватки. Выбирай между быстрым ударом, тяжёлой атакой, защитой и лечением. Противники опасны: не вступай в бой с низким здоровьем.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("ТВОЁ СНАРЯЖЕНИЕ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Оружие: ${when { inventory.contains("Тяжёлый палаш") -> "Тяжёлый палаш (+7)"; inventory.contains("Меч стражника") -> "Меч стражника (+4)"; inventory.contains("Охотничий клинок") -> "Охотничий клинок (+3)"; else -> "Архивный кинжал (+1)" }}\nЗащита: ${if (inventory.contains("Кольчуга стражника")) "Кольчуга (+3 к защите)" else "Дорожный плащ (без брони)"}", color = Ink, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            if (enemyName.isBlank()) {
                                Text("ОРУЖЕЙНАЯ · ПОКУПКА СНАРЯЖЕНИЯ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                if (!inventory.contains("Охотничий клинок")) Button(onClick = { if (gold >= 10) { gold -= 10; inventory.add("Охотничий клинок"); battleLog = "Куплен охотничий клинок (+3 к атаке)."; save() } else battleLog = "Не хватает золота: нужно 10." }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Охотничий клинок · 10 золота", color = Paper) }
                                if (!inventory.contains("Тяжёлый палаш")) Button(onClick = { if (gold >= 28) { gold -= 28; inventory.add("Тяжёлый палаш"); battleLog = "Куплен тяжёлый палаш (+7 к атаке)."; save() } else battleLog = "Не хватает золота: нужно 28." }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Тяжёлый палаш · 28 золота", color = Paper) }
                                Text("ВЫБЕРИ ПРОТИВНИКА", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Button(onClick = { startRandomEncounter() }, colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.fillMaxWidth()) { Text("🎲 Случайная встреча в пути", color = Ink) }
                                Button(onClick = { beginBattle("Древний рыцарь Чёрной розы", 105) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A2020)), modifier = Modifier.fillMaxWidth()) { Text("☠ БОСС: Древний рыцарь · 105 HP", color = Paper) }
                                Button(onClick = { beginBattle("Городской головорез", 32) }, colors = ButtonDefaults.buttonColors(containerColor = Leather), modifier = Modifier.fillMaxWidth()) { Text("Городской головорез · лёгкий бой", color = Paper) }
                                Button(onClick = { beginBattle("Наёмник Чёрной розы", 48) }, colors = ButtonDefaults.buttonColors(containerColor = Leather), modifier = Modifier.fillMaxWidth()) { Text("Наёмник Чёрной розы · опасный бой", color = Paper) }
                                Button(onClick = { beginBattle("Королевский изменник", 65) }, colors = ButtonDefaults.buttonColors(containerColor = Leather), modifier = Modifier.fillMaxWidth()) { Text("Королевский изменник · тяжёлый бой", color = Paper) }
                            } else {
                                Text("⚔ ПРОТИВНИК: $enemyName", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.animateContentSize().graphicsLayer { scaleX = enemyHitScale; scaleY = enemyHitScale })
                                StatLine("Здоровье противника", enemyHealth, when { enemyName.contains("Древний рыцарь") -> 105; enemyName.contains("изменник") -> 65; enemyName.contains("Наёмник") -> 48; else -> 32 })
                                StatLine("Твоё здоровье", health, 100)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    val attack = (9..14).random() + (if (inventory.contains("Тяжёлый палаш")) 7 else if (inventory.contains("Меч стражника")) 4 else if (inventory.contains("Охотничий клинок")) 3 else 1) + powerSkill * 2
                                    battlePulse++
                                    enemyHealth = (enemyHealth - attack).coerceAtLeast(0)
                                    battleLog = "Ты наносишь быстрый удар на $attack урона."
                                    if (enemyHealth == 0) winBattle() else enemyTurn()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Быстрый удар", color = Ink) }
                                Button(onClick = {
                                    val attack = (15..22).random() + (if (inventory.contains("Тяжёлый палаш")) 7 else if (inventory.contains("Меч стражника")) 4 else if (inventory.contains("Охотничий клинок")) 3 else 1) + powerSkill * 2
                                    battlePulse++
                                    enemyHealth = (enemyHealth - attack).coerceAtLeast(0)
                                    battleLog = "Ты замахиваешься и наносишь тяжёлый удар на $attack урона."
                                    if (enemyHealth == 0) winBattle() else enemyTurn()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Тяжёлый удар", color = Paper) }
                                Button(onClick = { battleGuarding = true; battleLog = "Ты принимаешь защитную стойку."; enemyTurn() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Защищаться", color = Paper) }
                                Button(onClick = {
                                    if (inventory.contains("Лечебный бальзам")) { inventory.remove("Лечебный бальзам"); health = (health + 30).coerceAtMost(100); battleLog = "Ты использовал бальзам и восстановил до 30 здоровья."; enemyTurn() }
                                    else battleLog = "Лечебного бальзама нет. Его можно купить у Миры в Нижнем городе."
                                    save()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Использовать бальзам (+30 HP)", color = Paper) }
                                TextButton(onClick = { enemyName = ""; enemyHealth = 0; battleLog = "Ты отступил. Победа не засчитана."; save() }) { Text("Отступить", color = Muted) }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("БОЕВОЙ ОТЧЁТ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(battleLog, color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                            Text("ПОБЕДЫ: $battleWins", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        "hero" -> { PaperHeading("ЛИЧНОЕ ДЕЛО"); Image(painter = painterResource(R.drawable.portrait_adrian), contentDescription = "Эдриан Вейл", modifier = Modifier.fillMaxWidth().height(150.dp).border(2.dp, Gold, RoundedCornerShape(5.dp)), contentScale = ContentScale.Crop); Spacer(Modifier.height(8.dp)); Text("Эдриан Вейл", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("24 года · хранитель королевских архивов", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); StatLine("Здоровье", health, 100); StatLine("Репутация", reputation.coerceIn(0,100), 100); StatLine("Доверие стражи", guard, 100); StatLine("Влияние при дворе", influence.coerceIn(0,100), 100); Text("Золото: $gold", color = Ink, fontSize = 14.sp); Spacer(Modifier.height(8.dp)); Text("УРОВЕНЬ $heroLevel · ОПЫТ $experience / ${heroLevel * 100}", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp); StatLine("Сила", powerSkill, 10); StatLine("Стойкость", guardSkill, 10); Text("Очки навыков: $skillPoints", color = Ink, fontSize = 13.sp); if (skillPoints > 0) { Button(onClick = { powerSkill++; skillPoints--; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Усилить атаку (+2 урона)", color = Ink) }; Button(onClick = { guardSkill++; skillPoints--; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Усилить защиту (+2 брони)", color = Paper) } } }
                        "dialogues" -> {
                            PaperHeading("ЛИЧНЫЕ БЕСЕДЫ · ГОЛОСА ЭСТЕРВАЛЯ")
                            Text("Выбери собеседника. Разговоры короткие, но ответы меняют доверие и могут открыть новые сведения. Персонажи помнят последний разговор.", color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Гаррет Морн", "Селеста", "Мира", "Томас", "Герцог Рейнар").forEach { name ->
                                    Button(onClick = { dialogNpc = name; dialogStage = 0; prefs.edit().putString("dialog_npc", name).putInt("dialog_stage", 0).apply() }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp), colors = ButtonDefaults.buttonColors(containerColor = if (dialogNpc == name) Gold else Leather)) {
                                        Text(name, color = if (dialogNpc == name) Ink else Paper, fontSize = 10.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            val portrait = when (dialogNpc) {
                                "Гаррет Морн" -> R.drawable.portrait_garrett
                                "Селеста" -> R.drawable.portrait_celeste
                                "Мира" -> R.drawable.portrait_mira
                                "Томас" -> R.drawable.portrait_thomas
                                else -> R.drawable.portrait_reynar
                            }
                            val greeting = when (dialogNpc) {
                                "Гаррет Морн" -> listOf("«Двери дворца закрыты, Вейл. Скажи, что ты ищешь — правду или неприятности?»", "«Я видел эту печать раньше. Но тот, кто её носил, давно числится мёртвым.»", "«Если решишь идти против Рейнара, сначала подумай, кто будет стоять за твоей спиной.»", "«На сегодня хватит. Доверие не выдают по первому требованию.»")
                                "Селеста" -> listOf("«Ты снова пришёл без приглашения, Эдриан. Значит, дело действительно важное.»", "«Некоторые письма опаснее кинжалов. Особенно если знаешь, кто их написал.»", "«Я не прошу верить мне. Я прошу дать мне возможность доказать правду.»", "«Береги наши разговоры. У стен дворца слишком хороший слух.»")
                                "Мира" -> listOf("«Если пришёл за покупками — плати. Если за слухами — сначала помоги людям.»", "«Лекарства исчезли не случайно. Кто-то скупает их для закрытого каравана.»", "«Я запомню, что ты не прошёл мимо. В этом городе это редкость.»", "«Возвращайся, когда рынок проснётся. У меня всегда найдётся работа.»")
                                "Томас" -> listOf("«Ночью море говорит громче людей. Я слышал, как грузчики называли одно имя.»", "«В ту ночь фонарь на третьем причале погас раньше смены. Это был знак.»", "«Я могу показать место, но не бесплатно: мне нужна гарантия безопасности.»", "«Не заставляй меня жалеть, что я заговорил.»")
                                else -> listOf("«Архивист решил заговорить с герцогом. Любопытно.»", "«Королевству нужен порядок. Иногда правда лишь мешает его восстановить.»", "«Я могу сделать тебя влиятельным. Но услуги двора никогда не бывают бесплатными.»", "«Подумай над предложением. Второго приглашения может не быть.»")
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                                Image(painter = painterResource(portrait), contentDescription = dialogNpc, modifier = Modifier.width(112.dp).height(142.dp), contentScale = ContentScale.Crop)
                                Column(Modifier.weight(1f)) {
                                    Text(dialogNpc.uppercase(), color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                                    Text(when(dialogNpc) { "Гаррет Морн" -> "Капитан королевской стражи"; "Селеста" -> "Дворянка · хранительница тайн"; "Мира" -> "Торговка Нижнего города"; "Томас" -> "Работник ночного порта"; else -> "Герцог · претендент на регентство" }, color = Muted, fontSize = 10.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("« ${greeting[dialogStage]} »", color = Ink, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.animateContentSize())
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("ТЕМА РАЗГОВОРА", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            val topics = listOf("Спросить о чёрной розе", "Обсудить пропавшего наследника", "Поговорить о доверии")
                            topics.forEachIndexed { index, topic ->
                                Button(onClick = {
                                    dialogStage = (dialogStage + 1).coerceAtMost(3)
                                    val delta = when(index) { 0 -> if (dialogNpc == "Селеста" || dialogNpc == "Герцог Рейнар") 2 else 1; 1 -> if (dialogNpc == "Гаррет Морн" || dialogNpc == "Томас") 2 else 1; else -> 1 }
                                    dialogTrust = (dialogTrust + delta).coerceAtMost(20)
                                    when(dialogNpc) { "Гаррет Морн" -> guard = (guard + delta).coerceAtMost(100); "Селеста" -> seleste = (seleste + delta).coerceAtMost(100); "Мира" -> miraBond = (miraBond + delta).coerceAtMost(100); "Томас" -> thomasBond = (thomasBond + delta).coerceAtMost(100); else -> reynarBond = (reynarBond + delta).coerceAtMost(100) }
                                    journal.add("Разговор с $dialogNpc: $topic.")
                                    save()
                                }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(8.dp), colors = ButtonDefaults.buttonColors(containerColor = if (index == 0) Gold else Leather)) {
                                    Text(topic, color = if (index == 0) Ink else Paper, fontSize = 11.sp)
                                }
                            }
                            Text("Доверие в беседах: $dialogTrust / 20 · беседа ${dialogStage + 1} из 4", color = Muted, fontSize = 10.sp)
                            Button(onClick = { dialogStage = 0; dialogTrust = 0; save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A3429))) { Text("Начать разговор заново", color = Paper, fontSize = 10.sp) }
                        }
                        "people" -> {
                            PaperHeading("ОТНОШЕНИЯ · ПАМЯТЬ · ЛИЧНЫЕ ИНТЕРЕСЫ")
                            Text("Персонажи помнят помощь, угрозы и обещания. Их связи друг с другом тоже меняются: союзники могут спорить, а соперники — использовать твои решения.", color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            Spacer(Modifier.height(8.dp))
                            PortraitRelationCard(R.drawable.portrait_garrett, "Капитан Гаррет Морн", "Верность долгу · память о встречах: $garrettMemory", guard, "Доверие")
                            PortraitRelationCard(R.drawable.portrait_celeste, "Леди Селеста", "Осторожная близость · память о встречах: $selesteMemory", (seleste + 50).coerceIn(0,100), "Расположение")
                            PortraitRelationCard(R.drawable.portrait_thomas, "Томас", "Ночной свидетель порта · память: $thomasMemory", (thomasBond + 100) / 2, "Дружба")
                            PortraitRelationCard(R.drawable.portrait_mira, "Мира", "Торговка Нижнего города · память: $miraMemory", (miraBond + 100) / 2, "Доверие")
                            PortraitRelationCard(R.drawable.portrait_reynar, "Герцог Рейнар", "Претендент на регентство", (reynarBond + 100) / 2, "Отношение")
                            Text("СВЯЗИ МЕЖДУ ПЕРСОНАЖАМИ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(socialEvent, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            if (socialConflict > 0) Text("Напряжение между союзниками: $socialConflict/3", color = Color(0xFF8B3428), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Button(onClick = { guard = (guard + 2).coerceAtMost(100); seleste = (seleste + 1).coerceAtMost(100); socialConflict = (socialConflict + 1).coerceAtMost(3); socialEvent = "Гаррет не одобряет тайные договорённости Селесты. Он предупредил тебя: однажды дворцовые интриги могут поставить стражу перед невозможным выбором."; journal.add("Отношения: Гаррет выразил недоверие методам Селесты."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Обсудить с Гарретом тайные связи двора", color = Paper) }
                            Button(onClick = { miraBond = (miraBond + 5).coerceAtMost(100); miraMemory++; gold += 2; socialEvent = "Мира передала Томасу немного еды для ночной смены. Он теперь обязан ей услугой."; journal.add("Отношения: помог Мире поддержать Томаса."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Помочь Мире передать припасы Томасу · +2 золота", color = Paper) }
                            Button(onClick = { reynarBond = (reynarBond + 4).coerceAtMost(100); influence += 2; socialConflict = (socialConflict - 1).coerceAtLeast(0); socialEvent = "Рейнар оценил твою сдержанность на переговорах. Напряжение между придворными немного ослабло, но герцог явно ждёт ответной услуги."; journal.add("Отношения: заключено временное перемирие с герцогом Рейнаром."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Провести дипломатическую встречу с Рейнаром", color = Paper) }
                            if (seleste >= 20 && (personalQuestFlags and 1) == 0) {
                                Spacer(Modifier.height(6.dp))
                                Text("ЛИЧНЫЙ МОМЕНТ · ЗАКРЫТАЯ ОРАНЖЕРЕЯ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("Селеста предлагает поговорить без свидетелей. Это не обещание любви, а осторожный шаг к доверию — и возможность узнать, чего она боится больше всего.", color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                                Button(onClick = { personalQuestFlags = personalQuestFlags or 1; seleste = (seleste + 6).coerceAtMost(100); influence += 1; socialEvent = "Селеста впервые рассказала Эдриану о страхе потерять право самой выбирать свою судьбу. Между вами возникло осторожное доверие."; journal.add("Отношения: тайный разговор с Селестой в оранжерее."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Выслушать Селесту · укрепить доверие", color = Ink) }
                            }
                            if (reynarBond >= 15 && (personalQuestFlags and 2) == 0) {
                                Button(onClick = { personalQuestFlags = personalQuestFlags or 2; reynarBond = (reynarBond + 5).coerceAtMost(100); influence += 2; socialEvent = "Рейнар признался, что его поддержка не бескорыстна: он хочет видеть Эдриана своим посредником при дворе."; journal.add("Отношения: Рейнар предложил тайный политический союз."); save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Выслушать тайное предложение Рейнара", color = Paper) }
                            }
                        }
                        "world" -> {
                            PaperHeading("КАРТА КОРОЛЕВСТВА ЭСТЕРВАЛЬ")
                            Text("Дороги королевства отмечены на старом пергаменте. Выбирай направление: некоторые места станут доступны по мере продвижения расследования.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(8.dp))
                            val locationArt = when (currentLocation) {
                                "Зимний сад" -> R.drawable.location_garden
                                "Нижний город" -> R.drawable.location_market
                                "Порт Веймар" -> R.drawable.location_harbor
                                "Старая часовня", "Старый мост" -> R.drawable.location_harbor
                                else -> R.drawable.location_castle
                            }
                            Box(Modifier.fillMaxWidth().height(116.dp).border(2.dp, Gold, RoundedCornerShape(5.dp))) {
                                Image(painter = painterResource(locationArt), contentDescription = "Вид на $currentLocation", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD17110E)))).padding(horizontal = 10.dp, vertical = 7.dp)) {
                                    Text(currentLocation.uppercase(), color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.fillMaxWidth().background(Color(0xFFD8C49B), RoundedCornerShape(6.dp)).border(2.dp, Color(0xFF89683E), RoundedCornerShape(6.dp)).padding(8.dp)) {
                                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("✥  СЕВЕРНЫЕ ЗЕМЛИ  ✥", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                                    Spacer(Modifier.height(6.dp))
                                    MapPlace("🏰 Королевский замок", currentLocation == "Королевский замок", true, "Главная крепость Эстерваль") { currentLocation = "Королевский замок"; journal.add("Прибытие: Королевский замок"); save() }
                                    Text("│   ╲", color = Muted, fontSize = 18.sp)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                        MapPlace("🌿 Зимний сад", currentLocation == "Зимний сад", sceneIndex >= 0, "Уединённое место Селесты") { currentLocation = "Зимний сад"; journal.add("Прибытие: Зимний сад"); save() }
                                        MapPlace("🌉 Старый мост", currentLocation == "Старый мост", sceneIndex >= 5, "Тайная каменная дверь") { currentLocation = "Старый мост"; journal.add("Прибытие: Старый мост"); save() }
                                    }
                                    Text("╲       │       ╱", color = Muted, fontSize = 18.sp)
                                    MapPlace("⚒ Нижний город", currentLocation == "Нижний город", sceneIndex >= 5, "Рынок и ремесленные кварталы") { currentLocation = "Нижний город"; journal.add("Прибытие: Нижний город"); save() }
                                    Text("│", color = Muted, fontSize = 18.sp)
                                    MapPlace("⚓ Порт Веймар", currentLocation == "Порт Веймар", sceneIndex >= 7, "Причалы и ночные поставки") { currentLocation = "Порт Веймар"; journal.add("Прибытие: Порт Веймар"); save() }
                                    MapPlace("⛪ Старая часовня", currentLocation == "Старая часовня", roseQuestStage >= 1, "Заброшенная часовня за портовой дорогой") { currentLocation = "Старая часовня"; journal.add("Прибытие: Старая часовня"); save() }
                                    Spacer(Modifier.height(8.dp))
                                    Text("✥  ЗА ПРЕДЕЛАМИ ГОРОДА  ✥", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                                    MapPlace("🛡 Северная застава", currentLocation == "Северная застава", sceneIndex >= 5, "Пограничный пост на старом тракте") { currentLocation = "Северная застава"; journal.add("Прибытие: Северная застава"); save() }
                                    MapPlace("🌾 Воронья деревня", currentLocation == "Воронья деревня", sceneIndex >= 5, "Деревня у холмов, где жители боятся леса") { currentLocation = "Воронья деревня"; journal.add("Прибытие: Воронья деревня"); save() }
                                    MapPlace("🌲 Лесной тракт", currentLocation == "Лесной тракт", sceneIndex >= 5, "Заброшенная дорога между деревней и заставой") { currentLocation = "Лесной тракт"; journal.add("Прибытие: Лесной тракт"); save() }
                                    Spacer(Modifier.height(4.dp)); Text("≈≈≈  РЕКА ЭСТЕР  ≈≈≈", color = Color(0xFF526C70), fontSize = 10.sp, letterSpacing = 2.sp)
                                }
                            }
                            Spacer(Modifier.height(9.dp))
                            Text("ТЕКУЩЕЕ МЕСТО: $currentLocation", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Путешествия записываются в летопись. Недоступные места откроются после новых событий.", color = Muted, fontSize = 11.sp)
                            if (currentLocation in listOf("Северная застава", "Воронья деревня", "Лесной тракт")) {
                                Spacer(Modifier.height(8.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text("СОБЫТИЕ В ПУТИ", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        val travelDescription = when (currentLocation) {
                                            "Северная застава" -> "Дозорный сообщает о пропавшем патруле. На снегу у ворот виден след чёрного воска."
                                            "Воронья деревня" -> "Староста просит найти пропавшего сборщика податей. Жители подозревают людей в гербовых плащах."
                                            else -> "У обочины лежит сломанная телега. В грязи заметны следы, ведущие к старому лесному святилищу."
                                        }
                                        Text(travelDescription, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                                        Spacer(Modifier.height(6.dp))
                                        Button(onClick = {
                                            val clue = when (currentLocation) {
                                                "Северная застава" -> "Осколок печати заставы"
                                                "Воронья деревня" -> "Список собранных податей"
                                                else -> "Знак лесного святилища"
                                            }
                                            if (!inventory.contains(clue)) inventory.add(clue)
                                            influence = (influence + 1).coerceAtMost(100)
                                            journal.add("Исследование: $currentLocation — получено: $clue.")
                                            worldEvent = "Находка в районе: $currentLocation. Новая улика добавлена в инвентарь."
                                            save()
                                        }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Осмотреть место и забрать улику", color = Paper, fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                        "council" -> {
                            PaperHeading("СОВЕТ СЕМИ ДОМОВ · БОРЬБА ЗА БУДУЩЕЕ ЭСТЕРВАЛЯ")
                            Text("Три заседания определят временный порядок в королевстве. Каждый голос меняет баланс сил: поддержка короны укрепляет гвардию, помощь горожанам снижает напряжение, а тайные сделки усиливают влияние Чёрной розы.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(9.dp))
                            StatLine("Политический баланс", (50 + councilBalance).coerceIn(0,100), 100)
                            Text("ЗАСЕДАНИЕ ${councilProgress + 1} / 3", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(councilReport, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            if (councilProgress < 3) {
                                Button(onClick = {
                                    councilProgress++; councilBalance = (councilBalance + 5).coerceAtMost(20); crownRep += 3; guard += 2; influence += 1
                                    councilReport = "Ты предложил укрепить королевскую гвардию и ограничить полномочия временного регента. Капитан Гаррет поддержал план, но торговые дома потребовали гарантий. Совет продолжится на следующем заседании."
                                    journal.add("Совет семи домов: поддержано укрепление гвардии."); save()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Укрепить гвардию и законный порядок", color = Paper, fontSize = 11.sp) }
                                Button(onClick = {
                                    councilProgress++; councilBalance = (councilBalance - 2).coerceAtLeast(-20); peopleRep += 5; gold = (gold - 3).coerceAtLeast(0)
                                    councilReport = "Ты потребовал отменить чрезвычайные сборы и открыть зерновые склады. Народные представители поддержали решение. Казна потеряла три золотых, зато улицы стали спокойнее."
                                    journal.add("Совет семи домов: поддержана помощь горожанам."); save()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Открыть склады и облегчить подати · −3 золота", color = Paper, fontSize = 11.sp) }
                                Button(onClick = {
                                    councilProgress++; councilBalance = (councilBalance - 5).coerceAtLeast(-20); roseRep += 5; influence += 4
                                    councilReport = "Ты заключил негласную сделку с представителем старого рода. Совет принял твоё предложение, но в зале погасли две свечи. Кто-то понял, с кем ты разговаривал."
                                    journal.add("Совет семи домов: заключена тайная политическая сделка."); save()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A3028))) { Text("Заключить тайную сделку с неизвестным домом", color = Paper, fontSize = 11.sp) }
                            } else {
                                Text("ИТОГ СОВЕТА", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(when { councilBalance >= 8 -> "Гвардия и сторонники порядка получили преимущество. Регенту придётся считаться с законом."; councilBalance <= -5 -> "Народные представители и тайные союзы изменили расстановку сил. В столице назревают перемены."; else -> "Ни одна сторона не получила решающего перевеса. Семь домов вынуждены искать компромисс." }, color = Ink, fontSize = 13.sp, lineHeight = 18.sp)
                                Button(onClick = { councilProgress = 0; councilReport = "Начался новый политический цикл. Дома ждут следующего решения."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Созвать новый совет", color = Ink) }
                            }
                        }
                        "companions" -> {
                            PaperHeading("СПУТНИКИ · ДОВЕРИЕ И СОВМЕСТНЫЕ ПУТЕШЕСТВИЯ")
                            Text("Выбери одного спутника для экспедиции. Его характер влияет на исход пути и на отношения. Спутники не бессмертны: рискованные решения могут стоить здоровья и доверия.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(8.dp))
                            listOf("Гаррет Морн" to "Военный опыт: снижает риск ранений.", "Селеста" to "Дипломатия: помогает находить ценные сведения.", "Мира" to "Знание города: чаще приносит припасы и золото.", "Томас" to "Морские связи: открывает редкие находки.").forEach { (name, skill) ->
                                Card(colors = CardDefaults.cardColors(containerColor = if (companion == name) Color(0xFFD4BE91) else Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), onClick = { companion = name; save() }) {
                                    Column(Modifier.padding(9.dp)) { Text((if (companion == name) "✓ " else "") + name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(skill, color = Muted, fontSize = 10.sp) }
                                }
                            }
                            Text("СПУТНИК: $companion · ДОВЕРИЕ: $companionBond", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Button(onClick = {
                                expeditionRuns++; advanceWorldTime(4)
                                when (companion) {
                                    "Гаррет Морн" -> { health = (health - 3).coerceAtLeast(1); inventory.add("Затупленный наконечник"); companionBond += 2; expeditionReport = "Гаррет заметил засаду раньше тебя. Вы избежали тяжёлого боя, но нашли лишь наконечник старой стрелы. Здоровье −3." }
                                    "Селеста" -> { influence += 3; inventory.add("Запечатанное письмо дома"); companionBond += 3; expeditionReport = "Селеста разговорила сторожа старого тракта. Ты получил запечатанное письмо и сведения о тайной встрече. Влияние +3." }
                                    "Мира" -> { gold += 4; inventory.add("Дорожные припасы"); companionBond += 2; expeditionReport = "Мира нашла короткий путь через торговые дворы. Вы вернулись с припасами и четырьмя золотыми. Золото +4." }
                                    else -> { inventory.add("Морская карта Веймара"); roseRep += 2; companionBond += 2; expeditionReport = "Томас провёл тебя к заброшенному причалу. В тайнике лежала морская карта с отметкой тайного маршрута. Влияние ордена +2." }
                                }
                                journal.add("Экспедиция со спутником $companion: $expeditionReport"); save()
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Отправиться в экспедицию · 4 часа", color = Ink) }
                            Text(expeditionReport, color = Ink, fontSize = 12.sp, lineHeight = 18.sp)
                            Text("Совместных экспедиций: $expeditionRuns", color = Muted, fontSize = 10.sp)
                        }
                        "houses" -> {
                            PaperHeading("СЕМЬ ВЕЛИКИХ ДОМОВ · ПОЛИТИЧЕСКИЙ БАЛАНС")
                            Text("Твои поступки постепенно меняют отношение влиятельных сил. Союзники могут открыть новые пути, а враги — закрыть ворота и начать охоту.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(12.dp))
                            RelationCard("Королевская корона", "Сторонники порядка и регентства", (50 + crownRep).coerceIn(0,100), "Поддержка")
                            RelationCard("Гильдии торговцев", "Купцы, перевозчики и банкиры", (50 + merchantRep).coerceIn(0,100), "Доверие")
                            RelationCard("Простой народ", "Ремесленники, рабочие и жители", (50 + peopleRep).coerceIn(0,100), "Народная поддержка")
                            RelationCard("Орден Чёрной розы", "Тайная сила из старых летописей", (50 + roseRep).coerceIn(0,100), "Влияние ордена")
                            Text("Показатели отражают известное Эдриану отношение фракций, а не точное число сторонников.", color = Muted, fontSize = 11.sp)
                        }
                        "life" -> {
                            PaperHeading("ЖИЗНЬ ЭСТЕРВАЛЯ · ЛЮДИ И ДЕЛА")
                            Text("Мир не замирает, пока Эдриан ищет правду. В разных местах его ждут знакомые лица, просьбы, сделки и слухи. NPC помнят важные разговоры.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("ТЕКУЩЕЕ МЕСТО: $currentLocation", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("ДЕНЬ $worldDay · ${worldHour.toString().padStart(2, '0')}:00 · $timePhase", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(worldEvent, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                                    Spacer(Modifier.height(5.dp))
                                    Button(onClick = { advanceWorldTime(3) }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("⏳ Подождать 3 часа", color = Paper) }
                                }
                            }
                            val npcSchedule = when (currentLocation) {
                                "Королевский замок" -> if (worldHour in 6..18) "Капитан Гаррет Морн находится у оружейной башни и проверяет караулы." else "Гаррет на ночном обходе стен. У караульной башни остался младший сержант." 
                                "Зимний сад" -> if (worldHour in 8..17) "Селеста гуляет у фонтана и готова к беседе." else "Селесты нет в саду: после заката она принимает гостей в покоях." 
                                "Нижний город" -> if (worldHour in 7..19) "Мира открыла лавку. Рынок шумит, ремесленники торгуются." else "Рынок закрыт. В переулках остались только поздние торговцы и дозорные." 
                                "Порт Веймар" -> if (worldHour in 20..23 || worldHour in 0..4) "Томас работает ночную смену. У причалов можно заметить подозрительные грузы." else "Томас отдыхает после смены. Днём на причалах кипит обычная работа." 
                                else -> if (worldHour in 20..23 || worldHour in 0..4) "У моста мелькает фигура в плаще. Возможно, это тайный связной." else "У моста встречаются путники и сборщики пошлин." 
                            }
                            Text("РАСПОРЯДОК ЖИТЕЛЕЙ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(npcSchedule, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            Spacer(Modifier.height(8.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("СЛУЧАЙНОЕ СОБЫТИЕ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(if (randomEventCount == 0) "Улицы полны слухов. Осмотрись: иногда небольшое происшествие меняет ход большого расследования." else worldEvent, color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                                    Button(onClick = {
                                        val event = (0..4).random()
                                        randomEventCount++
                                        when (event) {
                                            0 -> { gold += 3; worldEvent = "У мостовой ты находишь обронённый кошель. Внутри три золотых и записка с гербом одного из великих домов."; inventory.add("Записка с гербом дома"); journal.add("Случайное событие: найден кошель и записка.") }
                                            1 -> { health = (health - 5).coerceAtLeast(1); worldEvent = "На узкой улице вспыхивает драка. Ты помогаешь дозорному, но получаешь лёгкую рану. Здоровье −5."; journal.add("Случайное событие: уличная драка, здоровье −5.") }
                                            2 -> { peopleRep = (peopleRep + 3).coerceAtMost(100); reputation++; worldEvent = "Ремесленники просят помочь донести ящики. Простые люди запоминают твою помощь. Народная поддержка выросла."; journal.add("Случайное событие: помог ремесленникам.") }
                                            3 -> { influence++; worldEvent = "Незнакомец в сером плаще передаёт тебе обрывок шифра и исчезает в толпе. Возможно, это след Чёрной розы."; inventory.add("Обрывок неизвестного шифра"); journal.add("Случайное событие: получен обрывок шифра.") }
                                            else -> { gold = (gold - 2).coerceAtLeast(0); worldEvent = "Карманник пытается вытащить кошелёк. Ты замечаешь его слишком поздно и теряешь два золотых."; journal.add("Случайное событие: карманная кража, −2 золота.") }
                                        }
                                        advanceWorldTime(1)
                                        save()
                                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                        Text("Осмотреться · новое событие", color = Ink, fontSize = 11.sp)
                                    }
                                    Text("Найдено событий: $randomEventCount", color = Muted, fontSize = 10.sp)
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            when (currentLocation) {
                                "Королевский замок" -> {
                                    RelationCard("Капитан Гаррет Морн", "У оружейной башни · память о ваших встречах: $garrettMemory", (guard).coerceIn(0,100), "Доверие")
                                    Text("«Эдриан, стража устала от слухов. Скажи, что ты ищешь на самом деле». ", color = Ink, fontSize = 12.sp)
                                    Button(onClick = { guard=(guard+3).coerceAtMost(100); garrettMemory++; journal.add("Разговор с Гарретом: обсудили безопасность замка."); lastOutcome="Гаррет запомнил твою прямоту. Доверие гвардии немного выросло."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Поговорить о безопасности", color = Paper) }
                                    Button(onClick = { if (inventory.contains("Копия портовой накладной")) { guard=(guard+7).coerceAtMost(100); reputation++; journal.add("Передал Гаррету копию портовой накладной."); lastOutcome="Гаррет обещал проверить ночные поставки. Он теперь считает тебя полезным союзником." } else { lastOutcome="Гаррет просит принести доказательство ночных поставок из порта." }; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Обсудить ночные поставки", color = Paper) }
                                }
                                "Зимний сад" -> {
                                    RelationCard("Леди Селеста", "У фонтана · память о разговорах: $selesteMemory", (seleste+50).coerceIn(0,100), "Расположение")
                                    Text("«Слова — это тоже обещания. Я помню не только то, что ты сказал, но и то, чего не сказал».", color = Ink, fontSize = 12.sp)
                                    Button(onClick = { seleste=(seleste+4).coerceIn(-100,100); selesteMemory++; journal.add("Тайный разговор с Селестой в зимнем саду."); lastOutcome="Селеста поделилась слухом: один из кораблей покинул порт без королевской печати."; inventory.add("Слух о корабле без печати"); save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Выслушать её тайну", color = Paper) }
                                    Button(onClick = { if (gold>=2) { gold-=2; seleste=(seleste+2).coerceIn(-100,100); lastOutcome="Ты купил редкий чай для Селесты. Она оценила внимание."; journal.add("Подарил Селесте редкий чай.") } else lastOutcome="Не хватает золота на подарок (2 золотых)."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Купить редкий чай · 2 золота", color = Paper) }
                                }
                                "Нижний город" -> {
                                    RelationCard("Мира — торговка специями", "Рынок · знает городские слухи", (merchantRep+50).coerceIn(0,100), "Доверие")
                                    Text("«У меня есть товары и новости. Но бесплатных историй на рынке не бывает».", color = Ink, fontSize = 12.sp)
                                    Text("ТОРГОВАЯ ЛАВКА", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Button(onClick = { if (gold>=4) { gold-=4; inventory.add("Лечебный бальзам"); journal.add("Куплен лечебный бальзам за 4 золота."); lastOutcome="Бальзам добавлен в инвентарь. Его можно использовать в опасном путешествии." } else lastOutcome="Недостаточно золота: нужно 4."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Лечебный бальзам · 4 золота", color = Paper) }
                                    Button(onClick = { if (gold>=3) { gold-=3; inventory.add("Письмо без подписи"); merchantRep=(merchantRep+3).coerceIn(-100,100); lastOutcome="Мира продала тебе письмо без подписи. На бумаге пахнет речной солью."; journal.add("Куплено письмо без подписи у Миры.") } else lastOutcome="Недостаточно золота: нужно 3."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Письмо без подписи · 3 золота", color = Paper) }
                                    Button(onClick = { if (gold>=12 && !inventory.contains("Меч стражника")) { gold-=12; inventory.add("Меч стражника"); lastOutcome="Мира помогла достать меч стражника. Твои атаки стали сильнее."; journal.add("Куплен меч стражника за 12 золотых.") } else lastOutcome=if (inventory.contains("Меч стражника")) "Меч уже есть." else "Недостаточно золота: нужно 12."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Меч стражника · 12 золота", color = Ink) }
                                    Button(onClick = { if (gold>=15 && !inventory.contains("Кольчуга стражника")) { gold-=15; inventory.add("Кольчуга стражника"); lastOutcome="Ты приобрёл кольчугу. В бою она уменьшает входящий урон."; journal.add("Куплена кольчуга стражника за 15 золотых.") } else lastOutcome=if (inventory.contains("Кольчуга стражника")) "Кольчуга уже есть." else "Недостаточно золота: нужно 15."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Кольчуга стражника · 15 золота", color = Ink) }
                                    Button(onClick = { if (questStage==0) { questStage=1; journal.add("Задание принято: найти пропавший ящик с лекарствами."); lastOutcome="Мира просит найти ящик с лекарствами, исчезнувший по дороге к порту. Она обещает заплатить 8 золотых." } else if (questStage==1 && currentLocation=="Порт Веймар") { questStage=2; gold+=8; peopleRep=(peopleRep+4).coerceIn(-100,100); inventory.add("Пустая грузовая бирка"); lastOutcome="Ты нашёл ящик и вернул лекарства. Мира заплатила 8 золотых; народная поддержка выросла."; journal.add("Задание выполнено: ящик с лекарствами возвращён.") } else lastOutcome="Мира ждёт вестей о ящике с лекарствами. Ищи его в порту."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold), enabled = questStage<2) { Text(if (questStage==0) "Взять задание: пропавшие лекарства" else "Сообщить о выполнении задания", color = Ink) }
                                }
                                "Порт Веймар" -> {
                                    RelationCard("Томас — грузчик причала", "Смены по ночам · осторожен с чужаками", (peopleRep+50).coerceIn(0,100), "Расположение")
                                    Text("«Я ничего не видел. А если видел — мне за молчание платят».", color = Ink, fontSize = 12.sp)
                                    Button(onClick = { if (gold>=2) { gold-=2; merchantRep=(merchantRep+2).coerceIn(-100,100); inventory.add("Копия портовой накладной"); journal.add("Подкупил грузчика и получил копию портовой накладной."); lastOutcome="Томас передал копию накладной. Среди грузов отмечен ящик с королевской печатью." } else lastOutcome="Томас требует 2 золотых за сведения."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Заплатить за сведения · 2 золота", color = Paper) }
                                    Button(onClick = { if (questStage==1) { questStage=2; gold+=8; peopleRep=(peopleRep+4).coerceIn(-100,100); inventory.add("Пустая грузовая бирка"); lastOutcome="В ящике нашлись лекарства. Ты вернул их горожанам и получил обещанную награду: 8 золотых."; journal.add("В порту найден и возвращён ящик с лекарствами.") } else { randomEventCount++; val event = if (randomEventCount%2==0) "На мокрых досках ты находишь обрывок синей ткани. Он пахнет дымом и дорогими духами." else "Матрос шепчет о судне, которое каждую неделю уходит без огней. Его капитан носит перстень с чёрной розой."; inventory.add(if (randomEventCount%2==0) "Обрывок синей ткани" else "Слух о ночном судне"); lastOutcome=event; journal.add("Случайная находка в порту: $event") }; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text(if (questStage==1) "Проверить ящик с лекарствами" else "Осмотреть причалы", color = Paper) }
                                }
                                else -> {
                                    Text("У старого моста слышно, как вода бьётся о камни. Здесь можно искать следы и собирать улики.", color = Ink, fontSize = 13.sp)
                                    Button(onClick = { randomEventCount++; val clue=if(randomEventCount%2==0) "Следы сапог с гербовой пряжкой" else "Сломанная печать из чёрного воска"; inventory.add(clue); influence++; journal.add("Исследование старого моста: найдено — $clue."); lastOutcome="Ты обнаружил: $clue. Улика добавлена в инвентарь."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Тщательно осмотреть мост", color = Paper) }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("ЛИЧНЫЕ ИСТОРИИ · ЛЮДИ ПОМНЯТ ТВОИ ПОСТУПКИ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("У каждого знакомого есть собственные заботы. Повторные беседы открывают новые подробности; выполненные просьбы отмечаются в летописи.", color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5D5B8)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(9.dp)) {
                                    Text("ГАРРЕТ · ДОЛГ СТАРОГО СОЛДАТА", color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Память: $garrettMemory бесед · доверие гвардии: $guard", color = Muted, fontSize = 10.sp)
                                    Button(onClick = { garrettMemory++; if (garrettMemory >= 3 && personalQuestFlags and 1 == 0) { personalQuestFlags = personalQuestFlags or 1; inventory.add("Записка старого ветерана"); guard=(guard+5).coerceAtMost(100); lastOutcome="Гаррет доверяет тебе историю о ветеране, исчезнувшем после приказа с поддельной печатью. Ты получил записку с номером караульного журнала."; journal.add("Личная история Гаррета: получена записка ветерана.") } else { lastOutcome=if (personalQuestFlags and 1 != 0) "Гаррет уже рассказал тебе о старом ветеране. Теперь он ждёт результатов расследования." else "Гаррет вспоминает службу при Альдрике. Он станет откровеннее после нескольких честных разговоров." }; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Поговорить с Гарретом", color = Paper) }
                                    HorizontalDivider(color = Color(0xFFB49A70))
                                    Text("СЕЛЕСТА · ЦЕНА МОЛЧАНИЯ", color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Память: $selesteMemory бесед · расположение: $seleste", color = Muted, fontSize = 10.sp)
                                    Button(onClick = { selesteMemory++; if (seleste >= 12 && personalQuestFlags and 2 == 0) { personalQuestFlags = personalQuestFlags or 2; inventory.add("Половина шифрованного письма"); influence+=2; lastOutcome="Селеста признаётся, что её семья укрывала посланника исчезнувшего наследника. Она отдаёт половину письма; вторую хранит человек в порту."; journal.add("Личная история Селесты: получена половина шифрованного письма.") } else { lastOutcome=if (personalQuestFlags and 2 != 0) "Селеста уже поделилась семейной тайной. Её доверие теперь зависит от того, как ты распорядился письмом." else "Селеста говорит уклончиво. Ей нужно больше оснований доверять тебе (расположение не ниже 12)." }; save() }, enabled = personalQuestFlags and 2 == 0 || selesteMemory < 99, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Выслушать Селесту", color = Paper) }
                                    HorizontalDivider(color = Color(0xFFB49A70))
                                    Text("МИРА · ДОЛГ РЫНКА", color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Память: $miraMemory бесед · доверие купцов: $merchantRep", color = Muted, fontSize = 10.sp)
                                    Button(onClick = { miraMemory++; if (personalQuestFlags and 4 == 0 && questStage >= 2) { personalQuestFlags = personalQuestFlags or 4; gold+=5; merchantRep=(merchantRep+4).coerceIn(-100,100); inventory.add("Медная торговая метка"); lastOutcome="Мира помнит, что ты вернул лекарства. Она раскрывает тайник с оплатой для честного посредника: 5 золотых и торговая метка."; journal.add("Личная история Миры: заслужена торговая метка.") } else { lastOutcome=if (questStage < 2) "Мира просит сначала доказать, что ты не бросаешь людей в беде. Заверши задание о пропавших лекарствах." else "Мира рассказывает, как пережила голодную зиму и открыла лавку. Она считает тебя надёжным знакомым." }; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Поговорить с Мирой", color = Paper) }
                                    HorizontalDivider(color = Color(0xFFB49A70))
                                    Text("ТОМАС · СВИДЕТЕЛЬ НОЧНОГО ПОРТА", color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Память: $thomasMemory бесед · народная поддержка: $peopleRep", color = Muted, fontSize = 10.sp)
                                    Button(onClick = { thomasMemory++; if (worldHour in 20..23 || worldHour in 0..4) { if (personalQuestFlags and 8 == 0) { personalQuestFlags = personalQuestFlags or 8; inventory.add("Список ночных грузов"); peopleRep=(peopleRep+2).coerceIn(-100,100); lastOutcome="Ночью Томас решается показать список грузов. Один ящик отмечен знаком Чёрной розы и отправлен в старую часовню."; journal.add("Личная история Томаса: получен список ночных грузов.") } else lastOutcome="Томас больше не скрывает список. Он просит не называть его имя." } else lastOutcome="Томас не станет говорить при дневной смене. Попробуй вернуться в порт ночью."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Расспросить Томаса ночью", color = Paper) }
                                }
                            }
                            Text("ЛИЧНЫЕ ИСТОРИИ: ${Integer.bitCount(personalQuestFlags)} / 4 завершено", color = Muted, fontSize = 10.sp)
                            Text("ЗАДАНИЕ: ПРОПАВШИЕ ЛЕКАРСТВА", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(when(questStage) { 0 -> "Мира на рынке ещё не просила о помощи."; 1 -> "Найти ящик с лекарствами в порту Веймара."; else -> "Выполнено. Горожане запомнят твою помощь." }, color = Ink, fontSize = 12.sp)
                            Text("СЛУЧАЙНЫЕ СОБЫТИЯ: $randomEventCount", color = Muted, fontSize = 10.sp)
                        }
                        "quests" -> {
                            PaperHeading("ЖУРНАЛ ЗАДАНИЙ")
                            Text("ГЛАВА I · ЧЁРНАЯ РОЗА", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            val questTitles = listOf("Неизвестный груз", "След ведёт к часовне", "Письмо без подписи", "Чья сторона?", "Последствия выбора", "Цепочка завершена")
                            Text("Этап ${roseQuestStage.coerceAtMost(5)} / 5 · ${questTitles[roseQuestStage]}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(when (roseQuestStage) {
                                0 -> "Томас упоминал груз со знаком Чёрной розы. Найди его след в порту ночью. Нужен список ночных грузов или слух о ночном судне."
                                1 -> "В списке Томаса указан груз для старой часовни. Отправляйся туда и осмотри следы."
                                2 -> "В тайнике часовни найдено письмо. Теперь реши, кому доверить улику: Селесте или Гаррету."
                                3 -> "Союзник ждёт твоего решения. Можно передать письмо королевской страже или скрыть его и продолжить тайное расследование."
                                4 -> "Твой выбор повлиял на политические силы. Вернись к союзнику, чтобы завершить эту главу."
                                else -> "Ты завершил цепочку расследования. Последствия останутся в летописи и отношениях фракций."
                            }, color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(8.dp))
                            when (roseQuestStage) {
                                0 -> Button(onClick = { if (inventory.contains("Список ночных грузов") || inventory.contains("Слух о ночном судне")) { roseQuestStage = 1; journal.add("Цепочка Чёрной розы: найден след ночного груза."); lastOutcome = "След подтверждён. Груз направляли к старой часовне." } else lastOutcome = "Пока недостаточно улик. Поговори с Томасом ночью или осмотри причалы."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Проверить улики", color = Ink) }
                                1 -> Button(onClick = { if (currentLocation == "Старая часовня") { roseQuestStage = 2; inventory.add("Запечатанное письмо Чёрной розы"); journal.add("В старой часовне найдено запечатанное письмо."); lastOutcome = "Под каменной плитой ты нашёл письмо с печатью Чёрной розы." } else lastOutcome = "Сначала отправляйся в локацию «Старая часовня» на карте."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Осмотреть часовню", color = Ink) }
                                2 -> { Text("Выбери, кому доверить письмо:", color = Ink); Button(onClick = { roseQuestPath = 1; roseQuestStage = 3; seleste = (seleste+5).coerceIn(-100,100); influence += 2; journal.add("Письмо доверено Селесте. Она обещала расшифровать его."); lastOutcome = "Селеста принимает письмо и обещает расшифровать печать."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Доверить Селесте", color = Paper) }; Button(onClick = { roseQuestPath = 2; roseQuestStage = 3; guard = (guard+5).coerceAtMost(100); crownRep = (crownRep+4).coerceIn(-100,100); journal.add("Письмо передано Гаррету для проверки королевской печати."); lastOutcome = "Гаррет узнаёт во фрагменте знак старого караула и просит действовать осторожно."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Доверить Гаррету", color = Paper) } }
                                3 -> { Button(onClick = { roseQuestStage = 4; if (roseQuestPath == 1) { seleste = (seleste+3).coerceIn(-100,100); merchantRep = (merchantRep-1).coerceIn(-100,100); lastOutcome = "Селеста расшифровала часть письма: наследника видели живым после коронации." } else { crownRep = (crownRep+3).coerceIn(-100,100); roseRep = (roseRep+2).coerceIn(-100,100); lastOutcome = "Гаррет подтвердил подделку приказа. Королевская стража теперь насторожена." }; journal.add(lastOutcome ?: "Решение принято."); save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text(if (roseQuestPath == 1) "Продолжить тайное расследование" else "Передать сведения страже", color = Ink) } }
                                4 -> Button(onClick = { roseQuestStage = 5; gold += 12; experience += 25; if (roseQuestPath == 1) { roseRep = (roseRep+5).coerceIn(-100,100) } else { crownRep = (crownRep+3).coerceIn(-100,100) }; inventory.add("Печать старой часовни"); journal.add("Цепочка «Чёрная роза» завершена. Получено 12 золотых и 25 опыта."); lastOutcome = "Глава расследования завершена. Получено 12 золотых, 25 опыта и печать часовни."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Завершить расследование", color = Ink) }
                                else -> Text("Награды получены: 12 золота · 25 опыта · Печать старой часовни", color = Ink, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(14.dp)); HorizontalDivider(color = Color(0xFF8B6B45))
                            Text("ГЛАВА II · СОВЕТ СЕМИ ДОМОВ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${when (housesQuestStage) { 0 -> "Закрытое заседание"; 1 -> "Выбор союзника"; 2 -> "Последствия союза"; else -> "Голоса короны" }} · ${housesQuestStage}/3", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(when (housesQuestStage) {
                                0 -> "После находки в часовне герцогские посланники собираются на закрытый совет. Чтобы войти в большую политику, предъяви Печать старой часовни."
                                1 -> "Три силы готовы поддержать расследование, но каждая потребует свою цену. Торговцы хотят свободы пошлин; горожане — хлеба и защиты; сторонники Чёрной розы — тайны и осторожности."
                                2 -> "Союзник ждёт, когда ты докажешь, что выбор был не пустым обещанием. Последствия отразятся на влиянии домов."
                                else -> "Ты изменил расстановку сил перед Советом. Великие дома теперь считают Эдриана самостоятельным игроком."
                            }, color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            when (housesQuestStage) {
                                0 -> Button(onClick = { if (roseQuestStage >= 5 && inventory.contains("Печать старой часовни")) { housesQuestStage = 1; journal.add("Открыта глава II: приглашение на Совет семи домов."); lastOutcome = "Печать часовни открыла тебе двери закрытого совета. Три посланника ждут ответа." } else lastOutcome = "Сначала заверши расследование «Чёрная роза» и получи печать старой часовни."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Предъявить печать и войти", color = Ink) }
                                1 -> {
                                    Text("Кому предложить союз?", color = Ink, fontWeight = FontWeight.Bold)
                                    Button(onClick = { housesQuestPath = 1; housesQuestStage = 2; merchantRep = (merchantRep+8).coerceIn(-100,100); influence += 2; journal.add("Совет семи домов: заключён торговый союз."); lastOutcome = "Посланник гильдий принимает предложение. Он обещает открыть склады, но требует пересмотра королевских пошлин."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Гильдии торговцев — ресурсы и золото", color = Paper) }
                                    Button(onClick = { housesQuestPath = 2; housesQuestStage = 2; peopleRep = (peopleRep+8).coerceIn(-100,100); guard = (guard+3).coerceAtMost(100); journal.add("Совет семи домов: заключён союз с горожанами."); lastOutcome = "Представитель горожан поддерживает тебя. Народ ждёт защиты от произвола знати."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Горожане — поддержка и доверие", color = Paper) }
                                    Button(onClick = { housesQuestPath = 3; housesQuestStage = 2; roseRep = (roseRep+8).coerceIn(-100,100); influence += 4; journal.add("Совет семи домов: заключён тайный союз."); lastOutcome = "Безымянный посланник Чёрной розы предлагает сведения, но теперь твои шаги будут скрыты от большинства."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Тайный круг — влияние и секреты", color = Paper) }
                                }
                                2 -> Button(onClick = { housesQuestStage = 3; gold += if (housesQuestPath == 1) 15 else 5; experience += 35; influence += 2; inventory.add("Знак Совета семи домов"); journal.add("Глава II завершена. Выбранный союз изменил баланс сил."); lastOutcome = "Ты закрепил союз на Совете. Получено 35 опыта, знак Совета и награда золотом. Твой выбор будет иметь последствия в следующих главах."; save() }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Закрепить союз", color = Ink) }
                                else -> Text("Союз: ${when(housesQuestPath) { 1 -> "Гильдии торговцев"; 2 -> "Горожане"; 3 -> "Тайный круг"; else -> "не выбран" }} · Награды получены", color = Ink, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(12.dp)); HorizontalDivider(color = Color(0xFFB49A70))
                            Text("ДОПОЛНИТЕЛЬНЫЕ ЗАДАНИЯ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Пропавшие лекарства: ${if (questStage >= 2) "выполнено" else if (questStage == 1) "активно — ищи в порту" else "ещё не принято"}", color = Ink, fontSize = 12.sp)
                            Text("Личные истории: ${Integer.bitCount(personalQuestFlags)} / 4", color = Ink, fontSize = 12.sp)
                            Text("Решения в цепочке: ${when (roseQuestPath) { 1 -> "Селеста"; 2 -> "Гаррет"; else -> "ещё не выбрано" }}", color = Muted, fontSize = 11.sp)
                        }
                        "expeditions" -> {
                            PaperHeading("ЗАБЫТЫЕ МЕСТА · ЭКСПЕДИЦИИ")
                            Text("За пределами привычных дорог сохранились убежища старого королевства. Каждая вылазка расходует время; найденные улики и трофеи остаются с тобой.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(8.dp))
                            val weather = when ((worldDay + worldHour / 6 + weatherSeed) % 5) { 0 -> "Дождь над Эстервaлем"; 1 -> "Холодный туман"; 2 -> "Ясное небо"; 3 -> "Сильный ветер"; else -> "Мелкий снег в северных землях" }
                            Text("ПОГОДА · $weather", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("День $worldDay · ${worldHour.toString().padStart(2,'0')}:00 · $timePhase", color = Ink, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp)); HorizontalDivider(color = Color(0xFFB49A70))
                            Text("I · ПОДЗЕМЕЛЬЕ ЗАМКА", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Старые камеры под крепостью. Здесь могли хранить документы до основания нынешней династии. Прогресс: $dungeonKeep/4", color = Ink, fontSize = 12.sp)
                            Button(onClick = {
                                if (dungeonKeep < 4) {
                                    advanceWorldTime(1); dungeonKeep++
                                    when (dungeonKeep) {
                                        1 -> { inventory.add("Ржавый ключ подземелья"); expeditionNote = "В пыли найден ключ с гербом прежней династии."; gold += 2 }
                                        2 -> { health = (health - 8).coerceAtLeast(1); inventory.add("Обломок старой печати"); expeditionNote = "Каменная плита сдвинулась и задела тебя. Под ней лежал обломок печати." }
                                        3 -> { inventory.add("Записи тайного караула"); influence += 3; expeditionNote = "Ты обнаружил записи караула: приказы поступали из покоев регента." }
                                        4 -> { inventory.add("Королевский медальон"); experience += 60; expeditionNote = "В последней камере найден медальон пропавшего наследника. Это важнейшая улика." }
                                    }
                                    journal.add("Экспедиция: подземелье замка, этап $dungeonKeep. $expeditionNote"); save()
                                } else expeditionNote = "Подземелье замка исследовано полностью. Здесь больше нечего искать."
                            }, enabled = dungeonKeep < 4, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text(if (dungeonKeep < 4) "Исследовать следующую камеру · 1 час" else "Исследовано", color = Paper) }
                            Spacer(Modifier.height(9.dp)); HorizontalDivider(color = Color(0xFFB49A70))
                            Text("II · СКЛЕП СТАРОЙ ЧАСОВНИ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Запечатанный склеп открывается после продвижения расследования Чёрной розы. Прогресс: $dungeonCrypt/4", color = Ink, fontSize = 12.sp)
                            Button(onClick = {
                                if (roseQuestStage >= 1 && dungeonCrypt < 4) {
                                    advanceWorldTime(2); dungeonCrypt++
                                    when (dungeonCrypt) {
                                        1 -> { inventory.add("Свеча погребального обряда"); expeditionNote = "В нише сохранилась ритуальная свеча." }
                                        2 -> { if (health > 20) health -= 12 else gold = (gold - 4).coerceAtLeast(0); inventory.add("Кость с руной"); expeditionNote = "Ловушка сработала: рунический шип ранил тебя. В нише найдена кость с руной." }
                                        3 -> { inventory.add("Реестр тайных погребений"); roseRep += 4; expeditionNote = "Реестр доказывает, что некоторые люди официально умерли, но продолжали жить." }
                                        4 -> { inventory.add("Перстень смотрителя склепа"); experience += 75; expeditionNote = "В саркофаге найден перстень смотрителя — знак доступа к тайным криптам." }
                                    }
                                    journal.add("Экспедиция: склеп часовни, этап $dungeonCrypt. $expeditionNote"); save()
                                } else if (roseQuestStage < 1) expeditionNote = "Склеп закрыт. Сначала найди след Чёрной розы."
                                else expeditionNote = "Склеп полностью исследован."
                            }, enabled = roseQuestStage >= 1 && dungeonCrypt < 4, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text(if (roseQuestStage < 1) "Закрыто · нужен след Чёрной розы" else if (dungeonCrypt < 4) "Спуститься в склеп · 2 часа" else "Исследовано", color = Paper) }
                            Spacer(Modifier.height(9.dp)); HorizontalDivider(color = Color(0xFFB49A70))
                            Text("III · ЗАБЫТЫЙ АРХИВ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Тайное хранилище летописей, доступное тем, кто собрал печати и заслужил влияние. Прогресс: $dungeonArchive/4", color = Ink, fontSize = 12.sp)
                            Button(onClick = {
                                if (influence >= 5 && dungeonArchive < 4) {
                                    advanceWorldTime(2); dungeonArchive++
                                    when (dungeonArchive) {
                                        1 -> { inventory.add("План старого архива"); expeditionNote = "План показывает скрытый проход за книжными шкафами." }
                                        2 -> { inventory.add("Серебряная закладка"); gold += 8; expeditionNote = "За фальшивой стеной спрятана серебряная закладка и золото." }
                                        3 -> { inventory.add("Черновик завещания Альдрика III"); influence += 5; expeditionNote = "Черновик завещания указывает на подмену наследника." }
                                        4 -> { inventory.add("Письмо истинного наследника"); experience += 100; expeditionNote = "Ты нашёл письмо наследника. Оно меняет смысл всей истории." }
                                    }
                                    journal.add("Экспедиция: забытый архив, этап $dungeonArchive. $expeditionNote"); save()
                                } else if (influence < 5) expeditionNote = "Нужны влияние не менее 5 и доступ к старым архивным печатям."
                                else expeditionNote = "Архив полностью исследован."
                            }, enabled = influence >= 5 && dungeonArchive < 4, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text(if (influence < 5) "Закрыто · требуется влияние 5" else if (dungeonArchive < 4) "Изучить архив · 2 часа" else "Исследовано", color = Paper) }
                            Spacer(Modifier.height(10.dp)); HorizontalDivider(color = Color(0xFFB49A70))
                            Text("ПОСЛЕДНЯЯ НАХОДКА", color = Muted, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text(expeditionNote, color = Ink, fontSize = 13.sp, lineHeight = 18.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("ПОХОДНОЕ СНАРЯЖЕНИЕ И РЕМЕСЛО", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("Собирай травы и металл в мире, затем готовь припасы. Рецепт бальзама: 2 лечебные травы + 2 золота. Рецепт усиленной брони: 3 железных обломка + 8 золота.", color = Ink, fontSize = 12.sp, lineHeight = 17.sp)
                            Button(onClick = { advanceWorldTime(2); if ((1..100).random() <= 65) { inventory.add("Лечебная трава"); expeditionNote = "Ты собрал лечебную траву на обочине. Её можно использовать для приготовления бальзама." } else { inventory.add("Железный обломок"); expeditionNote = "Среди старого мусора найден железный обломок для кузнечного дела." }; journal.add("Сбор припасов в окрестностях: $expeditionNote"); save() }, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Собрать припасы в окрестностях · 2 часа", color = Paper) }
                            Button(onClick = { if (inventory.count { it == "Лечебная трава" } >= 2 && gold >= 2) { repeat(2) { inventory.remove("Лечебная трава") }; gold -= 2; inventory.add("Лечебный бальзам"); craftedCount++; journal.add("Ремесло: изготовлен лечебный бальзам."); expeditionNote = "Готово: лечебный бальзам добавлен в сумку." } else expeditionNote = "Не хватает двух лечебных трав или двух золотых."; save() }, enabled = inventory.count { it == "Лечебная трава" } >= 2 && gold >= 2, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Изготовить лечебный бальзам", color = Ink) }
                            Button(onClick = { if (inventory.count { it == "Железный обломок" } >= 3 && gold >= 8) { repeat(3) { inventory.remove("Железный обломок") }; gold -= 8; inventory.add("Усиленная кольчуга"); craftedCount++; journal.add("Ремесло: изготовлена усиленная кольчуга."); expeditionNote = "Кольчуга готова: её можно считать постоянным улучшением защиты." } else expeditionNote = "Не хватает трёх железных обломков или восьми золотых."; save() }, enabled = inventory.count { it == "Железный обломок" } >= 3 && gold >= 8, colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Сковать усиленную кольчугу", color = Paper) }
                            Text("Создано предметов: $craftedCount · Экспедиции: ${dungeonKeep + dungeonCrypt + dungeonArchive}/12", color = Muted, fontSize = 10.sp)
                        }
                        "items" -> { PaperHeading("ИНВЕНТАРЬ"); Text("Золото: $gold", color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); inventory.forEach { Text("▣  $it", color = Ink, fontSize = 14.sp); HorizontalDivider(color = Color(0xFFB49A70)) }; Spacer(Modifier.height(10.dp)); Text("Предметы, улики и расходники сохраняются между запусками игры.", color = Muted, fontSize = 12.sp) }
                        "journal" -> { PaperHeading("ЛЕТОПИСЬ СОБЫТИЙ"); if (journal.isEmpty()) Text("Твои решения появятся здесь.", color = Ink) else journal.forEachIndexed { i, entry -> Text("${i+1}. $entry", color = Ink, fontSize = 13.sp, lineHeight = 18.sp); Spacer(Modifier.height(7.dp)) } }
                        "about" -> {
                            PaperHeading("АВТОРСКАЯ ЛЕТОПИСЬ ПРОЕКТА")
                            Text("ПЕПЕЛ КОРОНЫ", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                            Text("ASHES OF THE CROWN · Версия 3.0.0", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("ОБ АВТОРЕ", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                            Text("Aziz Karabaev", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Автор идеи и создатель проекта", color = Ink, fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("ДАТА СОЗДАНИЯ", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                            Text("18 ноября 2026 года", color = Ink, fontSize = 15.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("СУТЬ ИГРЫ", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                            Text("Средневековая ролевая история о борьбе за власть в королевстве Эстерваль. Игрок становится Эдрианом Вейлом — хранителем королевских архивов — и расследует смерть короля, исчезновение наследника и тайну чёрной розы. Решения меняют отношения, репутацию, союзы и ход истории.", color = Ink, fontSize = 14.sp, lineHeight = 20.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("ЗАМЫСЕЛ ПРОЕКТА", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                            Text("Создать большую одиночную RPG с нелинейным сюжетом, запоминающими поступки NPC, политическими интригами, исследованием мира, торговлей и несколькими концовками. Игра рассчитана на автономную работу без постоянного интернета.", color = Ink, fontSize = 14.sp, lineHeight = 20.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("РАЗРАБОТКА", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                            Text("Android · Kotlin · Jetpack Compose\nТекущий этап: расширяемый игровой прототип. Версия 5.0.0 добавляет третью сюжетную главу «Северный поход» с тремя маршрутами, кризисом в деревне Серого Брода и развязкой в крепости Вальден. Выбор пути меняет репутацию, угрозу на тракте, ресурсы и отношения фракций. Сохранения версий 4.0.0 и 2.1.0 расширяются новыми полями без сброса прежнего прогресса. Новые системы дополняют сюжетные выборы, фракции, отношения, торговлю и пошаговые сражения.", color = Ink, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("© 2026 Aziz Karabaev · Пепел короны", color = Muted, fontSize = 11.sp)
                        }
                        else -> { PaperHeading(scene.chapter); Text(scene.title, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp); Text(scene.place, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Text(scene.text, color = Ink, fontSize = 14.sp, lineHeight = 21.sp); if (lastOutcome != null) { Spacer(Modifier.height(12.dp)); Text("ПОСЛЕДСТВИЯ", color = Color(0xFF80552C), fontWeight = FontWeight.Bold, fontSize = 11.sp); Text(lastOutcome!!, color = Ink, fontSize = 13.sp, lineHeight = 19.sp) } }
                    }
                }
                Column(Modifier.weight(0.92f).fillMaxHeight().background(Leather, RoundedCornerShape(4.dp)).border(2.dp, Gold, RoundedCornerShape(4.dp)).padding(11.dp)) {
                    Box(Modifier.weight(0.65f).fillMaxWidth().background(Brush.radialGradient(listOf(Color(0xFF70553A), Color(0xFF211914)))), contentAlignment = Alignment.Center) {
                        Image(painter = painterResource(id = R.drawable.estervale_book_art), contentDescription = "Иллюстрация мира Пепла короны", modifier = Modifier.fillMaxSize().alpha(0.48f), contentScale = ContentScale.Crop)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(when (sceneIndex) { 0 -> "♜"; 1 -> "⚔"; 2 -> "⌑"; 3 -> "❀"; 4 -> "♛"; else -> "✥" }, color = Gold, fontSize = 48.sp); Text("ЭСТЕРВАЛЬ", color = Paper, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text(scene.place.uppercase(), color = Gold, fontSize = 9.sp, textAlign = TextAlign.Center) }
                    }
                    Spacer(Modifier.height(8.dp)); Text("${if (chosen) "СЛЕДСТВИЯ ВАШЕГО ВЫБОРА" else "ВАШЕ РЕШЕНИЕ"}", color = Gold, fontSize = 10.sp, letterSpacing = 1.sp)
                    if (!chosen) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { availableChoices.forEachIndexed { i, choice ->
                            OutlinedButton(onClick = { makeChoice(choice) }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), border = BorderStroke(1.dp, Color(0xFF967344)), colors = ButtonDefaults.outlinedButtonColors(contentColor = Paper), shape = RoundedCornerShape(3.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) { Column(Modifier.fillMaxWidth()) { Text("${i+1}. ${choice.title}", fontSize = 12.sp, lineHeight = 15.sp); Text(choice.detail, color = Color(0xFFD0B98D), fontSize = 9.sp, lineHeight = 12.sp) } }
                        } }
                    } else {
                        Text(lastOutcome ?: "Выбор записан в летопись.", color = Paper, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 6.dp))
                        Button(onClick = { chosen = false; selectedPage = "story"; save() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), shape = RoundedCornerShape(3.dp)) { Text("Продолжить", fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(5.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("ЗОЛОТО  $gold", color = Gold, fontSize = 10.sp); Text("ЗДОРОВЬЕ  $health", color = Paper, fontSize = 10.sp) }
                }
            }
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ЭДРИАН ВЕЙЛ · $currentLocation", color = Gold, fontSize = 9.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { TextButton(onClick = { selectedPage = "journal" }) { Text("Хроника", color = Paper, fontSize = 10.sp) }; TextButton(onClick = { sceneIndex=0; reputation=0; housesQuestStage=0; housesQuestPath=0; guard=20; seleste=0; gold=18; health=100; influence=0; crownRep=0; merchantRep=0; peopleRep=0; roseRep=0; questStage=0; garrettMemory=0; selesteMemory=0; randomEventCount=0; enemyName=""; enemyHealth=0; battleWins=0; battleLog="Здесь появится ход сражения."; currentLocation="Королевский замок"; worldDay=1; worldHour=9; worldEvent="Город просыпается под звон колоколов."; lastOutcome=null; chosen=false; journal.clear(); inventory.clear(); inventory.addAll(listOf("Архивный ключ","Дорожный плащ","Пустой блокнот")); save() }) { Text("Новая игра", color = Gold, fontSize = 10.sp) } }
                Text("ВЕРСИЯ 4.0.0", color = Color.LightGray, fontSize = 9.sp)
            }
        }
        if (menuVisible) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF493423), Night, Color(0xFF0C0908)))).padding(18.dp), contentAlignment = Alignment.Center) {
                Row(Modifier.fillMaxWidth().fillMaxHeight(0.92f).background(Paper, RoundedCornerShape(8.dp)).border(3.dp, Gold, RoundedCornerShape(8.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Column(Modifier.weight(1.05f), verticalArrangement = Arrangement.Center) {
                        Image(painter = painterResource(R.drawable.estervale_book_art), contentDescription = "Обложка Пепла короны", modifier = Modifier.fillMaxWidth().height(190.dp).border(2.dp, Gold, RoundedCornerShape(5.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(10.dp))
                        Text("ХРОНИКИ ЭСТЕРВАЛЯ", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Text("ПЕПЕЛ КОРОНЫ", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                        Text("ASHES OF THE CROWN · 4.0.0", color = Muted, fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                        Text("ГЛАВНОЕ МЕНЮ", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Эдриан Вейл · $currentLocation", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { menuVisible = false; selectedPage = "story" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Продолжить", color = Ink) }
                        Text("СЛОТЫ СОХРАНЕНИЯ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        (1..3).forEach { slot ->
                            val label = prefs.getString("slot_${slot}_label", null)
                            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color(0xFFDCC9A4), RoundedCornerShape(5.dp)).border(1.dp, Color(0xFF9A7747), RoundedCornerShape(5.dp)).padding(7.dp)) {
                                Text("Слот $slot", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(label ?: "Пустой слот", color = Muted, fontSize = 9.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Button(onClick = { saveSlot(slot) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = Leather)) { Text("Сохранить", color = Paper, fontSize = 10.sp) }
                                    OutlinedButton(onClick = { loadSlot(slot) }, enabled = label != null, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp), border = BorderStroke(1.dp, Gold)) { Text("Загрузить", color = Ink, fontSize = 10.sp) }
                                }
                            }
                        }
                        Spacer(Modifier.height(5.dp))
                        OutlinedButton(onClick = { menuVisible = false; selectedPage = "about" }, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Gold)) { Text("Об игре", color = Ink) }
                        Text("Автосохранение включено · Музыка ${if (musicEnabled) "включена" else "выключена"}", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable private fun MapPlace(title: String, selected: Boolean, unlocked: Boolean, subtitle: String, onClick: () -> Unit) {
    Column(Modifier.padding(3.dp).widthIn(min = 112.dp).background(if (selected) Color(0xFFB99A68) else Color(0xFFE8D8B5), RoundedCornerShape(5.dp)).border(1.dp, if (unlocked) Color(0xFF876039) else Color(0xFF9A8A70), RoundedCornerShape(5.dp)).padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        TextButton(onClick = onClick, enabled = unlocked, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 1.dp)) { Text(if (unlocked) title else "🔒 $title", color = if (unlocked) Ink else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 13.sp) }
        Text(if (unlocked) subtitle else "Пока недоступно", color = Muted, fontSize = 8.sp, textAlign = TextAlign.Center, lineHeight = 10.sp)
    }
}

@Composable private fun PaperHeading(text: String) { Text(text, color = Muted, fontSize = 10.sp, letterSpacing = 2.sp); Spacer(Modifier.height(7.dp)) }
@Composable private fun PortraitRelationCard(imageId: Int, name: String, role: String, value: Int, label: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(0xFFDCC9A4), RoundedCornerShape(6.dp)).border(1.dp, Color(0xFF9A7747), RoundedCornerShape(6.dp)).padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painter = painterResource(imageId), contentDescription = "Портрет: $name", modifier = Modifier.width(76.dp).height(88.dp).border(2.dp, Gold, RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(role, color = Muted, fontSize = 10.sp, lineHeight = 13.sp)
            Spacer(Modifier.height(4.dp))
            StatLine(label, value, 100)
        }
    }
}

@Composable private fun RelationCard(name: String, role: String, value: Int, label: String) { Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(role, color = Muted, fontSize = 11.sp); Spacer(Modifier.height(5.dp)); StatLine(label, value, 100); Spacer(Modifier.height(7.dp)) }
@Composable private fun StatLine(name: String, value: Int, max: Int) { Column(Modifier.padding(vertical = 5.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = Ink, fontSize = 12.sp); Text("$value/$max", color = Ink, fontSize = 11.sp) }; LinearProgressIndicator(progress = { (value.toFloat()/max).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Color(0xFF876039), trackColor = Color(0xFFB99E72)) } }
